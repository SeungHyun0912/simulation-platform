# 프로젝트 기반 시뮬레이션 플랫폼 — 통합 개발 기술서

문서 패키지 1.0.0 · 기준일 2026-10-22

React / Python / PostgreSQL / SimPy 개발 인계용입니다. 설계 제안과 사용자 확정 정보, 미정 사항을 구분합니다.

## 목차

- [README.md](#doc-readme)
- [AGENTS.md](#doc-agents)
- [01_context_requirements.md](#doc-01-context-requirements)
- [02_erd_database.md](#doc-02-erd-database)
- [03_domain_contracts.md](#doc-03-domain-contracts)
- [04_api_contract.md](#doc-04-api-contract)
- [05_backend_python.md](#doc-05-backend-python)
- [06_frontend_react.md](#doc-06-frontend-react)
- [07_simulation_engine.md](#doc-07-simulation-engine)
- [08_catalog_processes.md](#doc-08-catalog-processes)
- [09_llm_wiki.md](#doc-09-llm-wiki)
- [10_cad_layout.md](#doc-10-cad-layout)
- [13_decisions_open_questions.md](#doc-13-decisions-open-questions)
- [11_roadmap_backlog.md](#doc-11-roadmap-backlog)
- [12_testing_operations.md](#doc-12-testing-operations)
- [14_handoff_prompts.md](#doc-14-handoff-prompts)
- [15_change_log.md](#doc-15-change-log)
- [99_sources.md](#doc-99-sources)


---

<a id="doc-readme"></a>

# 프로젝트 기반 이산 시뮬레이션 플랫폼 — 개발 인계 문서

- 문서 패키지: `1.0.0`
- 작성 기준일: `2026-10-22` / 표시 시간대: `Asia/Seoul`
- 상태: **개발 설계 제안서 / 사용자 공정정보를 포함한 검토용 기준본**
- 요청 기술: **React / Python / PostgreSQL / SimPy**
- 대상: 대화에 접근할 수 없는 다른 개발 AI 에이전트와 개발자
- 구현 상태: **소스 저장소, 구현 여부, 기존 DB와 CI 결과는 확인하지 못함. 체크리스트는 구현 완료를 의미하지 않음.**
- 과거 로드맵 MD 원본은 이번 파일 저장소에 없음. 이 패키지는 대화의 최신 합의를 토대로 재구성했으며 기존 체크리스트의 완료 상태를 승계하지 않음.

## 1. 먼저 알아야 할 것

플랫폼은 특정 전선 공장에 고정되지 않는다. **Project가 사용자가 선택하는 최상위 시뮬레이션 작업 범위**다.
사업체 간 보안 경계는 별도 `organization`으로 두고, 한 조직에 여러 프로젝트를 허용한다.
공장 전체, 일부 라인, 가상 검토 모델 모두 하나의 프로젝트가 될 수 있다.

현재 전선 제품 6종, 설비 96대, 공간 22곳은 **첫 번째 예제 프로젝트의 데이터**다.
개발 엔진, 화면, API에 제품명·설비 번호를 조건문으로 하드코딩하지 않는다.

현재 공정은 사람이 제공한 대표 모델이며 모두 검토용 초안이다.
정보 정리가 끝났다는 말은 모든 실행 조건이 확정되었다는 뜻이 아니다.
용량·예약·운반·일부 준비 발생 주기 등은 미정이다. 미정을 0 또는 무제한으로 바꾸지 않는다.

## 2. 권장 읽기 및 개발 순서

1. [AGENTS.md](#doc-agents): 에이전트 금지사항과 작업 절차
2. [01_context_requirements.md](#doc-01-context-requirements): 배경·범위·용어
3. [08_catalog_processes.md](#doc-08-catalog-processes): 최신 사용자 데이터, 정정 이력
4. [13_decisions_open_questions.md](#doc-13-decisions-open-questions): 확정/제안/미정 구분
5. **[02_erd_database.md](#doc-02-erd-database): ERD·테이블·제약을 먼저 검토**
6. [03_domain_contracts.md](#doc-03-domain-contracts): JSON·상태·수량 계약
7. [04_api_contract.md](#doc-04-api-contract): FE/BE 공통 API 계약
8. [05_backend_python.md](#doc-05-backend-python): Python 구현
9. [06_frontend_react.md](#doc-06-frontend-react): React 구현
10. [07_simulation_engine.md](#doc-07-simulation-engine): SimPy 실행 의미론
11. [11_roadmap_backlog.md](#doc-11-roadmap-backlog): 작업 순서·게이트
12. [12_testing_operations.md](#doc-12-testing-operations): 테스트·운영

후속 기능:
- [09_llm_wiki.md](#doc-09-llm-wiki)
- [10_cad_layout.md](#doc-10-cad-layout)
- [14_handoff_prompts.md](#doc-14-handoff-prompts)
- [15_change_log.md](#doc-15-change-log)
- [99_sources.md](#doc-99-sources)

## 3. 결정 상태의 의미

| 표기 | 의미 |
|---|---|
| USER_CONFIRMED | 사용자가 직접 확인한 제품·운영 조건 |
| PROPOSED | 이 문서에서 제안한 기술·설계, 구현 전 검토 |
| UNKNOWN | 답을 얻지 못함. 개발자가 임의 추정하지 않음 |
| SCENARIO_ASSUMPTION | 특정 시험 시나리오에서 명시·승인한 가정 |
| IMPLEMENTED | 코드·마이그레이션·테스트 증거가 확보되어야 사용 가능 |

사용자 도메인 사실과 기술 제안을 혼동하지 않는다. 예: React/Python/PostgreSQL은 사용자 선택,
FastAPI·SQLAlchemy·React Flow·작업 큐 방식은 제안이다.

## 4. 이번 문서의 실행 가능한 첫 목표

프로젝트 생성 → 설비와 IN/OUT 생성 → 저장공간 연결 → 제품 공정 초안 저장
→ 사전 검증 → 승인/가정 분리 → 단일 공정 시험 실행 → 이벤트·결과 확인.

현재 제품 6종 전체를 바로 정상 실행시키거나, 먼저 고급 CAD/자율 에이전트를 만드는 것이 첫 목표가 아니다.

## 5. 변경 관리

- 문서 파일은 저장소 `docs/platform/`에 넣고 Git으로 관리할 것을 제안한다.
- 루트 `AGENTS.md`에서 이 폴더의 AGENTS 문서를 읽도록 연결한다.
- 파일은 같은 이름으로 유지, 패키지 버전과 변경 이력을 갱신한다.
- DB → 도메인 DTO → API → 생성된 FE 타입 → 테스트 → 문서 순으로 영향 확인.
- 데이터 정정은 승인된 버전을 덮어쓰지 않고 새 초안/마이그레이션으로 남긴다.
- 이 대화와 외부 에이전트의 저장소는 자동 동기화되지 않는다.
  후속 변경 시 **최신 문서·관련 소스·마이그레이션 head·테스트 요약**을 함께 전달해야 한다.

## 6. 범위와 증거 한계

- 이 패키지는 기술 설계와 개발 작업 지시서다. 전체 운영용 코드·완성 DDL·실행된 테스트가 아니다.
- 날짜는 문서 작성 기준일이며 개별 SDK의 최신 버전을 보장하지 않는다. 정확한 의존성 버전은 착수 시 잠근다.
- 첨부 CAD ZIP에는 manifest/layers/texts/inserts만 있고 geometry는 없다.
  CAD 문자 위치를 실제 설비 중심 또는 IN/OUT으로 확정하지 않는다.
- 관련 공식 문서와 확인 범위는 [99_sources.md](#doc-99-sources)에 정리했다.



---

<a id="doc-agents"></a>

# AI 개발 에이전트 작업 지침

## 필수 준수

1. 시작 전에 README → 사용자 데이터 → 미정 목록 → ERD → DTO → API 순으로 읽는다.
2. 이 문서에 없는 도메인 조건을 상식으로 채우지 않는다.
3. 제품·설비·공간 코드는 예제 데이터다. `if product == ...`, `if code == "EQ-036"` 분기 금지.
4. `project_id`를 모든 프로젝트 데이터 접근·FK·캐시·파일·LLM 도구 범위에 적용한다.
5. 조직 인증과 프로젝트 권한을 백엔드에서 검증한다. 클라이언트/LLM이 보낸 ID는 권한 증거가 아니다.
6. 출발지 OUT → 도착지 IN, 저장공간 경유, 설비 내부 가공을 별개로 표현한다.
7. 작업물 개수, 길이, 가닥 수, 배치 크기, 산출 목표를 혼용하지 않는다.
8. 원문/명칭은 한국어를 사용한다. 코드 식별자는 영어 허용. 한자·일본어 주석 생성 금지.
   CAD 원본 문자 자체는 증거 보존이 필요하므로 원문을 파괴하지 말고 정규화 표시 필드를 분리한다.
9. 모르는 수치는 `unknown`. 0, 무제한, 미적용은 별도 값.
10. 승인된 공정·배치·시나리오 버전과 실행 스냅샷은 수정하지 않는다.
11. LLM에게 SQL 실행, 임의 Python 실행, 승인 없는 데이터 변경 권한을 주지 않는다.
12. 실물 설비 ID가 같으면 한 실행에서 한 자원이다. 방문 단계 수만큼 복제 금지.
13. 시뮬레이션 시간과 실제 서버 시간을 구분한다.
14. 긴 실행을 HTTP 요청 안이나 FastAPI 단순 응답 후 작업에 맡기지 않는다.
15. 기존 코드·DB·파일이 확인되지 않으면 있다고 주장하지 않는다. 테스트하지 않으면 “미실행”이라고 보고한다.

## 시작 절차

- [ ] 실제 저장소 구조, 언어·패키지 버전, CI, 기존 마이그레이션 확인
- [ ] 문서 패키지 버전과 기준 Git commit 기록
- [ ] 기존 구현과 문서의 차이 목록 작성
- [ ] 현재 작업을 11번 문서의 작업 ID에 연결
- [ ] 미정 사항이 구조 작업을 막는지, 실제 실행만 막는지 구분
- [ ] 바꿀 파일·스키마·API·테스트 계획을 짧게 제시
- [ ] 사용자가 승인한 범위만 변경

## 문서 우선순위

- 최신 사용자 정정 → 기록된 도메인 결정 → 승인된 ERD/DTO/API 계약 → 기술 제안 → 과거 예시.
- 원본 대화를 볼 수 없으므로 **08/13번 문서와 변경 이력**이 인계 기준이다.
- 충돌 발견 시 원본 값을 보존하고 `decision_pending`으로 보고한다.
- “최신 사용자 정정”을 주장하려면 입력 문서/요청 내용을 근거로 남긴다.

## 작업 단위

한 번에 작은 수직 기능을 완성한다. 예:
프로젝트 설비 생성 API + IN/OUT 원자적 생성 + DB 제약 + 화면 + 권한 테스트.
기능과 무관한 대규모 폴더 개편/패키지 교체/마이그레이션 리셋 금지.

## 완료 보고 형식

```text
작업 ID:
문서 패키지 버전 / Git 기준:
변경 파일:
DB 마이그레이션 head:
API 변경:
확정 또는 가정한 내용:
실행한 테스트와 결과:
실행하지 못한 테스트:
남은 위험 / 질문:
다음 에이전트 시작 지점:
갱신한 문서:
```

## 반드시 사람에게 질문할 때

- 시나리오에 필요한 미정값을 대신 확정해야 할 때
- 프로젝트 간 실물 설비를 실제로 공유 실행해야 할 때
- 기존 승인 데이터 또는 결과 삭제가 필요할 때
- 개인정보·공장 도면을 외부 LLM으로 전송하려 할 때
- 공정별 생산량 의미가 바뀌거나 단위 변환 근거가 없을 때
- 기존 테이블 대체, 공개 API breaking change, 비용 발생 외부 서비스 도입

## 문서 업데이트 원칙

`15_change_log.md` + 관련 기술서 + 테스트 ID를 같은 PR에서 변경한다.
원본 도메인 데이터 변경과 기술 설계 변경을 분리한다.
체크리스트는 실제 증거가 있을 때만 `[x]`로 바꾼다.



---

<a id="doc-01-context-requirements"></a>

# 01. 프로젝트 배경·요구사항

## 1. 목표와 비목표

목표: 다른 공장·사업체에도 적용할 수 있는 프로젝트 기반 생산 이산 시뮬레이션 플랫폼.
사용자는 공정·설비·공간·생산 시나리오를 등록하고 시뮬레이션 결과를 조회한다.
위키와 LLM은 동일한 기준정보와 실행 결과를 근거로 설명한다.
CAD는 위치·경로 편집을 돕는 입력 수단이며 엔진의 필수 의존성이 아니다.

초기 비목표:
- 실시간 설비 제어, PLC 명령 전송, 생산 자동 실행
- 3D 물리 엔진, 케이블의 상세 기계적 변형, 로봇 충돌 회피 제어
- 모든 제조 유형을 코드 추가 없이 처리하는 무제한 노코드 엔진
- CAD의 모든 객체를 PostgreSQL 행으로 적재
- LLM의 자율 변경·자율 실행·원시 SQL
- 프로젝트 간 실시간 공유 자원 스케줄링

## 2. 범위와 소유권

organization: 고객 사업체와 보안 경계.
project: 사용자가 선택하는 모델/실험 범위. 공장 전체나 일부 라인을 표현.
project_group: 프로젝트 안의 논리 그룹/라인. 여러 그룹이 동일 자산을 참조 가능.
zone: 배치 버전 안의 물리적 구역. 논리 그룹과 다르다.
asset: 설비/저장공간/도킹 지점의 고정 정체성.
asset_revision: 자산 능력·용량·정책의 버전.
node: 자산 IN/OUT/ACCESS 포트 또는 공정 그래프 노드. 두 용어를 DB 이름으로 구분.

프로젝트 복사 시 내부 ID를 새로 만들고 모든 참조를 변환한다.
다른 프로젝트의 같은 EQ 코드가 같은 실물 자원을 뜻하지 않는다.
동일 실행에서 공유 설비를 표현하려면 같은 프로젝트의 동일 asset_id를 사용한다.
복수 프로젝트 연합 실행은 별도 기능으로 유보한다.

## 3. 사용자 확정 요구사항

| ID | 내용 |
|---|---|
| REQ-001 | React 프런트엔드, Python 백엔드, PostgreSQL DB |
| REQ-002 | SimPy 기반 이산 시뮬레이션 |
| REQ-003 | Project별 설비·공간·공정·배치·결과 관리 |
| REQ-004 | 서비스 중에도 공정 Add/Update 지속 |
| REQ-005 | 설비는 항상 IN/OUT 존재 |
| REQ-006 | 기본 이동 시작은 도착 설비 가용 시. 도착 후 사용 중이면 IN 대기 |
| REQ-007 | OUT 배출은 목적지 수용 여부에 따라 대기 가능 |
| REQ-008 | 제품별/설비별/설비 조합별 조건을 분리 |
| REQ-009 | 길이·보빈·가닥·중량과 반제품 상태를 분리 |
| REQ-010 | 선속은 Output 기준. m/m 입력은 m/min으로 정규화 |
| REQ-011 | 선속만 제시한 공정은 길이 변화 없음 |
| REQ-012 | 원자재 전체 사용량/입고 계획은 제품 정의와 별도 시나리오 |
| REQ-013 | 위키·LLM 공정 질의, 후속 결과 질의 |
| REQ-014 | CAD 위치·공간·통로 편집은 후속 단계 |
| REQ-015 | 원자재/반제품/완제품 및 검사·적재 상태 구분 |
| REQ-016 | 초안과 메인 승인 반영을 구분 |
| REQ-017 | 최신 예제: 제품 6종, 설비 96대, 공간/도킹 22곳 |
| REQ-018 | 외부 에이전트가 대화 없이 개발할 문서와 변경 절차 필요 |

## 4. 중요한 업무 용어

- 공정 단계: 제품 경로상의 방문. 같은 설비를 재방문해도 단계 ID는 다르다.
- 설비군: 한 역할을 수행할 후보 자산 집합. 하나 선택과 동시 확보를 구분.
- 작업(operation): 투입 구성 한 번을 확보하고 목표 산출을 만드는 실행 단위.
- 산출 단위(output unit): 다음 공정에 전달 가능한 보빈/롤/다발 하나.
- 보빈: 작업물의 포장·권취 형태. 보빈 개수는 전선 길이/가닥 수가 아니다.
- 가닥 수: 동시 공급 구성. 13가닥을 합친다고 13배 산출 길이가 되지 않는다.
- 잔량: 작업 후 남은 길이/중량. 설정에 따라 이월/폐기/보관.
- 가용: 설비 운전·점유·예약·근무시간 등을 만족하는 조건. 단순 idle만을 뜻하지 않음.
- 수용 가능: 목적지 용량과 필요한 자원·예약 조건을 만족.
- 생산 완료: 제품별 지정 공정 도달. 검사 완료·출하/적재와 다를 수 있다.

## 5. 단위 정책 — 설계 제안

저장/계산: 길이 m, 중량 kg, 시간 min, 좌표 m, 회전 degree.
서버 실제 시간: UTC timestamptz, 화면 Asia/Seoul 기본.
시뮬레이션 시각: 실제 날짜가 아니라 시작점 기준 min; 필요하면 시나리오 시작 일시에 매핑.
화면은 t/시간/초도 허용하되 변환값과 원입력 단위를 보존.
기준 수량은 numeric, API는 decimal string 사용. 엔진 시간은 검증 후 float 변환.
도면 좌표 단위와 모델 내 공정 길이 단위를 섞지 않는다.

## 6. 운영 가정 관리

미정 데이터가 있어도 초안 저장·위키 표시·설계 검토는 가능하다.
실행은 해당 시나리오가 사용하는 필수 정보만 검증한다.
임시값은 `scenario_version.assumptions`에 이유·승인자·대상 경로를 기록한다.
예: “이번 단일 공정 시험에서는 운반시간 0분 가정”은 허용 가능하나
“공장 전체 운반시간은 0분으로 확정”은 금지.

## 7. 초기 사용자 역할 — 제안

org_admin: 조직 관리 및 멤버 관리. 모든 프로젝트 열람은 별도 정책으로 명시.
project_admin: 프로젝트 설정·권한·보관 관리.
editor: 초안 수정, 검증 요청.
reviewer: 버전 승인/반려.
operator: 승인 모델 시나리오 실행/취소.
viewer: 승인 정보·허용된 결과 조회.
MVP에서는 계정 하나가 여러 역할을 가질 수 있으나 역할별 테스트는 분리한다.

## 8. 문서 외부 의존성

기술 프레임워크 동작에 관한 근거는 [99_sources.md](#doc-99-sources).
이 문서의 데이터 구조·제품 규칙은 사용자 요구와 설계 제안이며, 외부 자료에서 가져온 공장 사실이 아니다.



---

<a id="doc-02-erd-database"></a>

# 02. PostgreSQL ERD·데이터베이스 개발 기술서

> 상태: PROPOSED. 이 문서를 먼저 검토한 후 Backend/Frontend DTO를 확정한다.
> 사용자 데이터 기준: [08](#doc-08-catalog-processes). JSON 계약: [03](#doc-03-domain-contracts).
> 초기 초안의 equipment/storage 분리안 대신 공통 `asset` + 하위 상세 테이블을 제안한다.
> 목적은 자산 포트·그룹·배치·감사에서 다형 참조를 줄이기 위함이다. 기존 DB가 있다면 즉시 교체하지 말고 마이그레이션 계획부터 제시한다.

## 1. 설계 원칙

1. UUID 내부 ID는 고정, EQ/ST 표시 코드·정렬은 변경 가능.
2. 프로젝트 자원은 모두 project_id를 갖고 FK까지 프로젝트 일치를 강제.
3. 공정 흐름(논리 그래프)과 운반 통로(물리 그래프)를 분리.
4. 제품 공정, 자산 설정, 배치, 시나리오는 각각 버전 관리.
5. 실행 입력은 완전한 불변 스냅샷. 승인 버전도 실행 시점에 복제하여 보존.
6. FK가 필요한 관계는 컬럼/관계 테이블로 저장. JSON의 임의 ID만으로 연결하지 않음.
7. JSONB는 종류별 수량/시간/잔량 정책에만 사용하고 schema_version으로 검증.
8. 현재 전선 공장은 예제 project. 모든 사업체를 같은 EQ 코드 전역 UNIQUE로 제한하지 않음.
9. 승인 상태와 실행 준비 상태는 다르다. 명시적 UNKNOWN을 포함한 지식 승인 가능.
10. 현재 이 문서의 SQL은 제약 패턴 예시이며 전체 실행용 DDL이 아니다.

## 2. 핵심 ERD

```mermaid
erDiagram
    ORGANIZATION ||--o{ PROJECT : owns
    APP_USER ||--o{ PROJECT_MEMBER : joins
    PROJECT ||--o{ PROJECT_MEMBER : grants
    PROJECT ||--o{ PROJECT_GROUP : groups
    PROJECT ||--o{ ASSET : owns
    PROJECT_GROUP ||--o{ GROUP_ASSET : maps
    ASSET ||--o{ GROUP_ASSET : shared
    ASSET ||--o{ ASSET_REVISION : versions
    ASSET ||--o{ ASSET_PORT : exposes
    ASSET_REVISION ||--o{ PORT_POLICY : configures
    ASSET_PORT ||--o{ PORT_POLICY : targets
    ASSET ||--o| EQUIPMENT_DETAIL : specializes
    ASSET ||--o| SPACE_DETAIL : specializes
    PROJECT ||--o{ PRODUCT : owns
    PRODUCT ||--o{ PROCESS_VERSION : versions
    PROCESS_VERSION ||--o{ FLOW_NODE : contains
    FLOW_NODE ||--o| PROCESS_STEP : operates
    PROCESS_STEP ||--o{ RESOURCE_REQUIREMENT : requests
    RESOURCE_REQUIREMENT ||--o{ REQUIREMENT_CANDIDATE : chooses
    ASSET ||--o{ REQUIREMENT_CANDIDATE : eligible
    PROCESS_STEP ||--o{ STEP_MATERIAL_SPEC : transforms
    PROCESS_VERSION ||--o{ FLOW_EDGE : connects
    FLOW_NODE ||--o{ FLOW_EDGE : endpoints
    PROJECT ||--o{ LAYOUT_VERSION : versions
    LAYOUT_VERSION ||--o{ PORT_PLACEMENT : places
    ASSET_PORT ||--o{ PORT_PLACEMENT : located
    LAYOUT_VERSION ||--o{ NETWORK_NODE : routes
    NETWORK_NODE ||--o{ NETWORK_EDGE : endpoints
    PROJECT ||--o{ SCENARIO : owns
    SCENARIO ||--o{ SCENARIO_VERSION : versions
    SCENARIO_VERSION ||--o{ SCENARIO_PRODUCT : plans
    PROCESS_VERSION ||--o{ SCENARIO_PRODUCT : pinned
    SCENARIO_VERSION ||--o{ SCENARIO_ASSET : pins
    ASSET_REVISION ||--o{ SCENARIO_ASSET : used
    SCENARIO_VERSION ||--o{ SIMULATION_RUN : executes
    SIMULATION_RUN ||--|| RUN_INPUT_SNAPSHOT : freezes
    SIMULATION_RUN ||--o{ RUN_ATTEMPT : attempts
    RUN_ATTEMPT ||--o{ WORK_ITEM : creates
    RUN_ATTEMPT ||--o{ SIMULATION_EVENT : records
    RUN_ATTEMPT ||--o{ METRIC_RESULT : aggregates
```

ERD는 주요 관계다. 자세한 유일성·소유권·연결 규칙은 아래 표와 제약 목록이 우선한다.

## 3. 공통 컬럼·자료형

모든 일반 엔터티:
- `id uuid PK`: 앱에서 생성. DB UUID 생성 확장에 의존하지 않음.
- `created_at timestamptz`, `created_by uuid NULL`
- 수정 가능한 행에 `updated_at`, `updated_by`, `row_version bigint NOT NULL DEFAULT 1`
- 보관 가능한 기준정보에 `archived_at timestamptz NULL`
- 사용자 도메인 설명에 `notes text`, 필요한 경우 `field_meta jsonb NOT NULL DEFAULT '{}'`
- 프로젝트 소유 행에 `project_id uuid NOT NULL`, `UNIQUE(project_id,id)`
- 하위 버전 소유 행에 `project_id`, `..._version_id`와 해당 복합 FK

숫자:
- 길이·중량·선속·용량: `numeric(24,6)`; 범위 밖 입력 거부.
- 시뮬레이션 시간: DB `double precision`, finite/nonnegative 검증; 세부 비교 허용오차 명시.
- 횟수·보빈 수: `bigint` 및 양수/0 허용 의미별 CHECK.
- 상태: 초기에는 `text + CHECK`, 허용값은 DTO와 공유. 무관리 자유 문자열 금지.
- JSONB: 기본 `{}`가 미정 필드를 숨기지 않도록 모델별 schema_version·필수 discriminant 검증.
- 개인정보/비밀값/원본 CAD 전체를 JSONB 설정에 넣지 않는다.

## 4. 단계 A — 프로젝트·기준정보

| 테이블 | 필수 업무 컬럼 및 관계 | 주요 제약 |
|---|---|---|
| organization | name, code, status | code 고유 |
| app_user | auth_issuer, auth_subject, display_name, status | UNIQUE(issuer,subject); 외부 인증 연결 |
| organization_member | organization_id, user_id, role | 조직/사용자/역할 유일 |
| project | organization_id, code, name, timezone, description, status | UNIQUE(organization_id,code); project root |
| project_member | project_id, user_id, role | 사용자·역할 중복 금지; 조직 멤버 확인 |
| project_group | project_id, parent_id NULL, code, name, group_type | parent 동일 project; 순환 금지 |
| asset | project_id, kind, code, name, sort_order, external_ref NULL | kind equipment/storage/dock; UNIQUE(project_id,code) |
| equipment_detail | project_id, asset_id PK, equipment_type, model_name NULL | asset.kind=equipment 검증 |
| space_detail | project_id, asset_id PK, space_type | storage/dock만; 공간 용량은 revision |
| asset_alias | project_id, asset_id, alias, source | 동일 asset 별칭 중복 금지; 별칭 전역 유일 강제 안 함 |
| group_asset | project_id, group_id, asset_id, role | UNIQUE(project_id,group_id,asset_id) |
| asset_port | project_id, asset_id, port_key, role, label | port_key 자산 내 고유; 설비 IN/OUT 각 1개; 공간 ACCESS 기본 1개 |
| asset_revision | project_id, asset_id, revision_no, status, properties, approved_at/by | UNIQUE(asset_id,revision_no); 승인 후 불변 |
| port_policy | project_id, asset_revision_id, asset_id, port_id, capacity_rule, dispatch_rule, release_rule | 동일 asset의 revision·port만 연결 |
| audit_log | organization_id, project_id NULL, actor_id, action, entity_type, entity_id, before/after, request_id | append-only; 민감 필드 마스킹 |

equipment_detail은 식별 분류만, 능력·운전 용량·가용 달력·버퍼 정책은 asset_revision.properties/port_policy.
asset.code/name 변경은 식별 표시 변경이며 과거 snapshot에는 당시 표시를 보존한다.
asset_revision은 승인을 위한 상태와 미정 필드를 보유할 수 있다. 시나리오는 승인된 revision을 명시적으로 선택한다.

### 포트 정합성

- 설비 생성 서비스는 asset + equipment_detail + IN/OUT을 같은 트랜잭션에서 생성.
- `UNIQUE(project_id,asset_id,port_key)`로 포트 키 중복 방지.
- IN/OUT 역할은 해당 역할에 대한 부분 유일 인덱스로 각각 한 개를 강제.
  ACCESS는 ACCESS-01/02처럼 port_key를 달리해 추후 여러 접근 지점을 지원.
- “정확히 IN/OUT 2개 존재”는 CHECK 한 줄로 다른 행을 세지 않는다.
  서비스 테스트 + 커밋 시 지연 제약 트리거로 보장하는 것을 제안한다.
- 공간의 ACCESS는 물리 포인트일 뿐 저장 용량을 따로 중복 계산하지 않는다.
- 공간 capacity는 asset_revision의 저장 용량, IN/OUT capacity는 port_policy의 버퍼 용량.
- 도킹이 대기 적재를 허용하는지는 UNKNOWN이며 실제 포트가 있다고 용량을 무제한으로 해석하지 않는다.

## 5. 단계 A — 제품·공정 정의

| 테이블 | 업무 컬럼 및 관계 | 제약 |
|---|---|---|
| product | project_id, code, name, specification | 프로젝트 내 코드 고유 |
| material_definition | project_id, code, name, form, default_spec | 원자재/반제품 종류. 공정 단계와 독립된 재료 식별 |
| process_version | project_id, product_id, version_no, status, schema_version, base_version_id NULL, raw_unit_spec, finished_unit_spec, completion_node_id NULL | version 고유, 승인 후 수정 금지 |
| flow_node | project_id, process_version_id, node_key, kind, label, asset_id NULL, milestone_type NULL, input_match_policy, display_order | kind source/buffer/operation/join/milestone/sink |
| process_step | project_id, process_version_id, node_id UNIQUE, operation_type, handler_version, timing_rule, output_rule, material_rule, handoff_rule, execution_rule | node.kind=operation; 선속·규칙 JSON 검증 |
| resource_requirement | project_id, process_version_id, step_id, role_key, resource_kind, selection_mode, required_count, capacity_mode, allocation_rule | 역할 키 단계 내 고유 |
| requirement_candidate | project_id, process_version_id, requirement_id, asset_id, eligibility_status, parameter_override | 프로젝트 동일; 조건 override 스키마 검증 |
| step_material_spec | project_id, process_version_id, step_id, spec_key, direction, material_definition_id NULL, state_code, form, length_m NULL, weight_kg NULL, unit_count NULL, strand_count NULL, quantity_basis, field_meta | 숫자/상태 조건, spec_key 유일 |
| flow_edge | project_id, process_version_id, edge_key, from_node_id, to_node_id, edge_kind, source_output_spec_id NULL, target_input_spec_id NULL, movement_rule, condition_rule | 양끝 동일 버전; type material/precedence/supply |
| process_editor_state | project_id, process_version_id, user_id NULL, node_positions, viewport, row_version | 화면 좌표 전용, 물리 위치와 무관 |
| validation_report | project_id, target_kind, target_id, target_row_version, scope, content_hash, issues, validated_at | 범용 참조는 감사용; 운영 FK 대신 쓰지 않음 |
| change_request | project_id, target_kind, target_id, description, status, decided_by/at | 변경 승인/질문 이력; 근거 원문 보존 |

### 연결 모델

공정 그래프에서 저장공간은 명시적인 buffer 노드다.
예: operation(절연) → buffer(ST-011) → operation(조사).
물류 경유도 operation(테이핑) → buffer(ST-022) → buffer(ST-009) → operation(쉬스).

- buffer/source/sink 노드는 asset_id로 실제 공간을 참조할 수 있다.
- operation 노드는 자산 하나를 직접 박지 않고 resource_requirement의 후보에서 선택.
- operation에서 나가는 material edge는 선택 자산 OUT, 들어오는 edge는 선택 자산 IN으로 실행 시 해석.
- 같은 물리 공간을 방문해도 공정상 역할이 다르면 flow_node는 별도, asset_id는 동일.
- join은 준비 조건을 나타내며 설비로 집계하지 않음.
- supply는 원자재 지원/직결 공급, precedence는 완료 의존성. 단순 운반과 혼용 금지.
- source_output_spec/target_input_spec은 필요할 때 매칭을 엄격히 지정.
  연결된 spec이 실제 endpoint step에 속하는지 서비스 검증.
- 동일 asset로 재방문하는 경로는 정상. 그래프의 실제 순환·재작업은 초기 비지원, 등록은 경고/실행 차단.

### 설비 후보 선정

`selection_mode=one_of`: 후보 가운데 required_count개를 고르는 방식.
`selection_mode=all_of`: 표시된 필수 구성 자원을 모두 확보.
후보 qualification이 UNKNOWN이면 시나리오에서 가정 승인 전 실행 불가.
그룹 전체가 미래에 자동 후보로 늘어나지 않게 승인 시 candidate ID를 고정한다.
노동자 무제한은 `resource_kind=worker, capacity_mode=unlimited`; 가짜 EQ 설비를 생성하지 않는다.

## 6. 단계 C — 시나리오·실행·결과

| 테이블 | 업무 컬럼 | 주의 |
|---|---|---|
| scenario | project_id, name, description | 변경 이력의 root |
| scenario_version | project_id, scenario_id, version_no, status, layout_version_id NULL, calendar_rule, arrival_rules, initial_wip, stopping_rule, assumptions, engine_options | 승인 후 불변 |
| scenario_product | project_id, scenario_version_id, product_id, process_version_id, production_plan, priority | product와 version 일치 |
| scenario_asset | project_id, scenario_version_id, asset_id, asset_revision_id, availability_override | revision의 asset 일치 |
| simulation_run | project_id, scenario_version_id, status, requested_by, requested_at, seed, replicate_index, engine_version, input_hash, idempotency_key, selected_attempt_id NULL | 프로젝트+요청자+key 고유 |
| run_input_snapshot | project_id, run_id UNIQUE, schema_version, snapshot jsonb, sha256 | 수정·삭제 금지 정책 |
| job | project_id, run_id NULL, kind, state, priority, available_at, lease_owner/token, lease_expires_at, attempt_count, payload | DB queue. payload에 비밀 금지 |
| run_attempt | project_id, run_id, attempt_no, state, fencing_token, heartbeat_at, started_at, finished_at, termination_reason, error_detail | run/attempt_no 유일 |
| work_item | project_id, attempt_id, item_key, material_definition_id NULL, product_snapshot_key, lot_key, state_code, form, length_m, weight_kg, location_key, completion_flags | run attempt scoped 상태 |
| work_item_relation | project_id, attempt_id, parent_item_id, child_item_id, operation_key, relation_type, allocated_length_m NULL, allocated_weight_kg NULL, accounting_mode | split/merge/carry/abstract |
| simulation_event | project_id, attempt_id, event_seq, sim_time_min, event_type, step_key NULL, asset_key NULL, item_key NULL, payload | UNIQUE(attempt_id,event_seq) |
| metric_result | project_id, attempt_id, metric_key, dimensions, dimensions_hash, value, unit, definition_version, window_start/end, quality_status | 동일 지표/차원/구간 유일 |
| comparison | project_id, name, baseline_run_id, target_run_id, comparison_policy, caveats | 동일 project; 입력 차이 표시 |

여기서 snapshot_key/step_key/asset_key는 **해당 실행 snapshot의 UUID 문자열**이다.
현재 master와 강한 FK를 맺어 과거 결과를 지우지 않는다. snapshot 내부 참조는 compile 시 검증한다.
work_item의 material_definition_id도 선택적이며 과거 품목명/상태는 snapshot에서 해석한다.
선택된 성공 attempt 하나만 공식 결과로 집계, 실패 attempt 데이터는 진단용으로 분리.

## 7. 단계 E — 물리 배치·이동 네트워크

| 테이블 | 업무 컬럼 |
|---|---|
| layout_version | project_id, version_no, status, coordinate_unit, origin_transform, floor_system, source_artifact_id NULL |
| zone | project_id, layout_version_id, code, name, floor_key, boundary_geometry, verification_status |
| asset_placement | project_id, layout_version_id, asset_id, footprint, orientation, zone_id NULL, verification_status |
| port_placement | project_id, layout_version_id, port_id, x_m, y_m, z_m, floor_key, evidence_id NULL, verification_status |
| network_node | project_id, layout_version_id, code, x_m, y_m, z_m, node_type |
| network_edge | project_id, layout_version_id, from_node_id, to_node_id, length_m, width_m NULL, allowed_modes, capacity_rule, geometry, verification_status |
| port_network_attachment | project_id, layout_version_id, port_id, network_node_id, access_length_m, verification_status |
| transport_resource | project_id, code, mode, status |
| transport_resource_revision | project_id, resource_id, revision_no, speed_rule, load_rule, loading_rule, calendar_rule, status |
| scenario_transport | project_id, scenario_version_id, resource_id, resource_revision_id |
| cad_import | project_id, artifact_id, status, extractor_version, units, report, transform_rule |
| cad_mapping | project_id, cad_import_id, source_entity_path, target_asset_id NULL, target_port_id NULL, confidence, review_status, evidence |

- 초기 물리 좌표는 nullable. route manual duration으로 검증 실행 가능.
- geometry는 초기 JSON 좌표 배열/GeoJSON 유사 구조, 외부 GIS 좌표계라고 주장하지 않는다.
- 공간 검색 필요가 확인되면 PostGIS 도입 ADR. 초기 필수 확장으로 만들지 않는다.
- network_edge는 방향성 edge. 양방향은 두 edge 또는 shared_segment_key로 단일 통행 용량 공유.
- 운반 중 막힘/교차로 경쟁을 모델링하기 전에는 최단거리만으로 혼잡 효과를 주장하지 않는다.

## 8. 단계 B/D — 위키·LLM·파일

| 테이블 | 업무 컬럼 |
|---|---|
| artifact | project_id, kind, storage_key, filename, byte_size, sha256, content_type, scan_status, retention_policy |
| evidence | project_id, artifact_id NULL, source_kind, reference_text, received_at, author, claim_scope |
| wiki_document | project_id, source_type, source_id, source_version, status, generated_markdown, manual_notes, content_hash |
| indexing_job | project_id, document_id, action, status, source_hash |
| retrieval_chunk | project_id, document_id, source_version, text, metadata, index_generation |
| conversation | project_id, user_id, title, allowed_scope |
| conversation_message | project_id, conversation_id, role, content, references, run_id NULL |
| llm_tool_call | project_id, conversation_id, caller_user_id, tool_name, validated_arguments, result_reference, latency, status |
| outbox_event | project_id, event_type, aggregate_id, version, payload, published_at NULL |

embedding/vector DB는 초기 필수가 아니다. 정형 조회 API + 제한된 문서 검색을 우선 구현.
공장 도면/공정 원문은 외부 모델에 기본 전송하지 않는다.

## 9. 무결성 패턴

PostgreSQL의 UNIQUE/FK/CHECK는 행 값과 관계를 보호하는 수단이며, 다른 행/테이블 전체 검증은
서비스 또는 적절한 트리거로 분리한다. FK 컬럼 인덱스는 별도로 설계한다. [S01](#s01)

```sql
-- 제약 패턴 예시, 전체 DDL 아님
ALTER TABLE asset
  ADD CONSTRAINT uq_asset_project_id UNIQUE (project_id, id),
  ADD CONSTRAINT uq_asset_code UNIQUE (project_id, code);

ALTER TABLE asset_port
  ADD CONSTRAINT fk_port_asset
  FOREIGN KEY (project_id, asset_id)
  REFERENCES asset(project_id, id)
  ON DELETE RESTRICT;

-- 하위 포트 정책은 asset_revision, asset_port 양쪽의 asset_id까지 검증:
-- FK(project_id, asset_id, asset_revision_id) -> asset_revision(project_id, asset_id, id)
-- FK(project_id, asset_id, port_id) -> asset_port(project_id, asset_id, id)
```

flow_edge:
- FK(project_id,process_version_id,from_node_id) → flow_node의 같은 복합 유일 키.
- to_node, step, candidate, spec도 동일 패턴.
- completion_node_id는 자기 version의 milestone/node만 허용, 생성 순환은 nullable로 저장 후 연결.
- kind-dependent subtype는 제약 트리거 + 서비스 검사. JSON 검증만으로 대체 금지.

## 10. 권한·RLS

제안: API 권한 검사 + project-scoped repository + PostgreSQL RLS 방어.
RLS는 테이블 owner/superuser/BYPASSRLS 사용 여부에 따라 우회될 수 있으므로
운영 앱 계정과 migration 계정을 분리하고 우회 권한을 주지 않는다. [S02](#s02)

예시 정책 개념:
```sql
USING (
  project_id = NULLIF(current_setting('app.project_id', true), '')::uuid
)
WITH CHECK (
  project_id = NULLIF(current_setting('app.project_id', true), '')::uuid
);
```

이 예시만으로 사용자 권한이 검증되지는 않는다.
인증된 멤버 검증 → 트랜잭션 내부 set_config(..., true) → repository 수행 순서를 지킨다.
project 선택값은 요청 body가 아니라 권한 검증된 경로 값. 연결 풀에 세션 전체 값 잔류 금지.
project 목록은 조직/멤버 전용 접근 정책으로 별도 구현.
worker job claim은 최소권한 전용 큐 계정/함수, 실제 모델 접근은 해당 project context.
LLM에게 SQL 또는 DB 세션 설정 권한을 주지 않는다.

## 11. 인덱스·동시성·삭제

- asset/product: (project_id,code), (project_id,kind,archived_at)
- flow_node/edge/step: (project_id,process_version_id)
- candidate: (project_id,asset_id), FK 대응 인덱스
- simulation_event: (attempt_id,sim_time_min,event_seq), (attempt_id,asset_key,event_seq)
- work_item: (attempt_id,item_key), (attempt_id,state_code)
- job: state/available_at/priority에 claim용 인덱스
- snapshot JSONB 전체 GIN은 기본 금지. 실제 조회 목적 확인 후 추가.
- 대량 event는 초기 단일 테이블; 측정 후 파티션/압축/외부 보관 결정.

PATCH는 row_version 기반 compare-and-swap. 충돌은 412.
승인과 저장은 동일 트랜잭션 경쟁 검증으로 “승인 직전 수정” 방지.
참조된 master는 hard delete 금지, archive. 실행/감사 데이터는 보존정책에 따른 별도 승인 삭제.
개발 편의상 전체 schema drop을 마이그레이션 방법으로 사용하지 않는다.

## 12. 마이그레이션 순서

1. organization/user/project/membership
2. asset/subtype/port/group/alias
3. asset_revision/port_policy
4. product/material/process_version/node/step
5. requirements/spec/edge + 복합 FK
6. validation/audit/change_request
7. artifact/outbox/wiki/LLM (단계 B)
8. scenario/version/bindings (C0/C와 병행)
9. run/snapshot/job/attempt/event/item/metric
10. layout/network/CAD/transport

Alembic 자동 생성 결과는 후보 마이그레이션이며 반드시 수동 검토한다. [S07](#s07)
승인 불변 트리거, RLS, 복합 FK, 데이터 backfill은 autogenerate만 믿지 않는다.

## 13. ERD 승인 게이트

- [ ] 같은 코드의 설비를 프로젝트 2개에 등록 가능
- [ ] 프로젝트 A 포트가 B 자산을 참조할 수 없음
- [ ] 그룹 2개에 등록한 한 설비가 실행에서 한 자원임
- [ ] 설비 생성/삭제 시 포트 invariant 보장
- [ ] 같은 설비의 1차/2차 조사 step이 다른 속도 보유 가능
- [ ] AL 공급/선행/메인 연결이 분리 가능
- [ ] 프로젝트 복사 시 UUID와 관련 참조 전체 재생성
- [ ] approved 버전 변경 차단 및 clone-to-draft 가능
- [ ] 실행 snapshot만으로 외부 DB 조회 없이 모델 컴파일 가능
- [ ] unknown/zero/unlimited/not_applicable 구분
- [ ] flow editor 좌표와 CAD 좌표가 다른 테이블에 저장
- [ ] 회원·권한·자원 범위의 부정 테스트 작성


## 14. 승인/복제 구현에서 빠뜨리기 쉬운 제약

- scenario_asset의 (project_id,asset_id,asset_revision_id)를 revision의 같은 자산에 복합 FK.
- scenario_product의 process_version이 product_id와 같은 제품인지 복합 FK.
- run.selected_attempt_id는 해당 run의 attempt만 지정 가능. 복합 FK 또는 검증 트리거.
- snapshot은 run당1개이며 hash와 내용의 일치를 작성 시 검증.
- approved 버전의 자식 step/edge/spec/candidate 변경도 금지.
  부모 status만 API에서 검사하고 자식 직접수정을 허용하면 불변성이 깨진다.
- graph 저장 경쟁은 부모 process_version row_version을 증가시키며 step PATCH도 같은 lock을 사용.
- project clone은 기존 버전 UUID·step/spec/edge/candidate/port 전체 매핑을 새로 생성.
  원본 승인 기록을 새 프로젝트 승인으로 위조하지 않고 기본 draft로 복사.
- 자산 subtype 변경(equipment→space)은 기존 포트 참조 때문에 단순 PATCH 금지.
- 하나의 source edge에서 여러 input으로 복제되면 단순 fan-out이 아니라 split/allocate 규칙 필요.
- relational schema의 “노드종류와 하위테이블 관계”는 일반 FK만으로 완성되지 않으며 service/trigger 시험 필수.

## 15. 필드 메타데이터와 근거

field_meta는 JSON Pointer별 status/source_ref/reason을 저장하며,
숫자값과 status가 모순되지 않도록 DTO와 DB 진입 서비스에서 검증한다.
예: setup duration=0 confirmed는 유효, duration=null confirmed는 적용 방식에 따라 거부.
DB 차원의 숫자양수 CHECK는 JSON 스키마 검증을 대신하지 않는다.
원문·정정은 evidence/change_request에서 연결하며 승인자/시각을 자동 생성해 꾸미지 않는다.


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).


## 16. 첫 PR 범위와 후속 테이블

전체 표는 목표 구조다. 첫 PR에서 모든 테이블과 화면을 한 번에 만들지 않는다.
첫 PR: organization/app_user/members/project + asset/subtype/asset_port와 기본 권한·감사.
두 번째 묶음: asset_revision/port_policy/group 및 product/process.
이후 scenario/run/LLM/CAD 순서. 후속 FK의 참조 테이블은 해당 기능 도입 시 migration한다.
예: scenario_version.layout_version_id는 초기 nullable 예약 필드 또는 후속 ADD COLUMN+FK로 도입.
존재하지 않는 테이블을 참조하는 migration을 실행시키지 않는다.



---

<a id="doc-03-domain-contracts"></a>

# 03. 도메인·JSON·실행 입력 계약

> PROPOSED. 컬럼은 02, API는 04, 시뮬레이션 의미는 07을 함께 읽는다.
> 아래 JSON은 규격 예시이며 UUID가 필요한 자리에 실제 ID를 제공해야 한다.
> API DTO와 DB ORM을 그대로 같은 객체로 사용하지 않는다.

## 1. 고정 계약

- `schema_version`: 문자열, 초기 `"1.0"`.
- 외부 자원 관계: UUID. EQ/ST/제품명은 표시/입력 해석용, FK 아님.
- API decimal: `"1000.000000"` 형식 문자열. JS number로 긴 숫자를 왕복 저장하지 않음.
- 개수: JSON integer. 좌표·시뮬레이션 시간: finite number.
- null: 값 미정/미적용. `field_meta`로 사유 반드시 표현.
- 빈 문자열은 null이 아님. 숫자 단위가 맞지 않으면 422.
- 저장 규칙 객체에는 discriminator `kind` 또는 `mode` 필수.
- 알려지지 않은 필드를 기본 거부. 확장필드는 명시적인 `extensions` namespace만.
- enum 추가 시 schema migration/하위 호환 전략 기록.

Pydantic의 discriminated union으로 정책 종류별 검증을 구성하는 것을 제안한다. [S08](#s08)

## 2. 상태 구분

버전: `draft → in_review → approved`; 반려 시 `in_review → draft`.
승인 버전은 superseded/deprecated 표시가 가능하되 내용 수정은 금지.
초안 보관 상태는 archived; 승인 해제 대신 새 버전 작성.

값 상태:
- confirmed: 사용자가 확인한 값
- unknown: 답 없음
- not_applicable: 적용 대상 아님
- assumed: 특정 시나리오 가정. master 승인 사실로 승격 금지

```json
{
  "length_m": null,
  "weight_kg": "2000",
  "field_meta": {
    "/length_m": {"status": "unknown", "reason": "입력되지 않음"},
    "/weight_kg": {"status": "confirmed", "source_ref": "USR-P04-RAW"}
  }
}
```

임의 크기 UNKNOWN을 `-1`, `Infinity`, `99999999`로 표현하지 않는다.

## 3. 용량 계약

```json
{
  "mode": "finite",
  "value": "4",
  "unit": "item",
  "status": "confirmed"
}
```

mode:
- unknown: value/unit null 가능, 실행할 때 해소
- finite: value>0, item이면 정수
- unlimited: value null
- not_allowed: 해당 포트에 대기 적재 불가. “0 용량 Store” 생성하지 않음

지원 unit: item, bobbin_slot, pallet_slot, kg, m2 등.
초기 엔진은 item만 지원하고 다른 단위는 등록 가능/실행 비지원으로 명시한다.
공간 body와 ACCESS 포트가 동일 물량을 이중 점유하지 않도록 storage owner를 지정한다.

## 4. 시간 계약

### 4.1 길이 기반 순차 산출

```json
{
  "schema_version": "1.0",
  "processing": {
    "kind": "output_speed",
    "speed_m_per_min": "32",
    "basis": "per_stream",
    "output_schedule": "sequential_units",
    "parallel_streams": 1
  },
  "setup": {"duration_min": "0", "trigger": "not_applicable"},
  "precondition_delay": {"duration_min": "0", "trigger": "not_applicable"}
}
```

- per_stream + sequential_units: 한 산출 보빈 L/v, 다음 보빈도 같은 속도로 순차 가공.
- per_stream + parallel_streams: 각 가닥/보빈이 동시에 v로 생성. 그룹 산출 시점을 별도 정의.
- aggregate_output: 총 산출 길이 합계의 처리속도. 개별 보빈 배출 스케줄도 별도 필요.
- 산출 스케줄/속도 기준이 미정이면 full run 차단; 현재 AL/CU 멀티신선이 해당.

`parallel_streams=1`은 모든 공정의 자동 기본이 아니라 위 예시의 명시적 설정이다.

### 4.2 산출 단위당 고정시간

```json
{
  "processing": {
    "kind": "per_output_unit",
    "duration_min": "22",
    "output_schedule": "sequential_units"
  },
  "setup": {"duration_min": "0", "trigger": "not_applicable"}
}
```

CU 태신선 22분/보빈, 검사 10분/보빈을 표현할 수 있다.
다만 여러 보빈을 병렬 처리할 능력과 시간 기준은 별도 자원 설정이다.

### 4.3 기준 길이당 시간

```json
{
  "processing": {
    "kind": "per_reference_length",
    "reference_length_m": "1000",
    "duration_min": "720",
    "scaling": "unknown",
    "includes_setup": "unknown"
  }
}
```

scaling=linear를 확인하기 전 다른 길이로 자동 비례 계산 금지.
시간에 준비 포함이면 setup을 추가하여 중복 가산하지 않음.

### 4.4 공급 지연

```json
{
  "processing": {"kind": "none"},
  "precondition_delay": {
    "duration_min": "120",
    "trigger": "unknown",
    "occupancy": "unknown"
  }
}
```

AL 싱글-12. `speed=0`을 나누거나, 별도 생산 120분으로 매 보빈에 반복 적용하지 않음.

준비 trigger: per_operation, per_input_replacement, per_output_replacement,
on_product_change, on_shift_start, once_per_run, unknown, not_applicable.
제품 교체시간은 이전→다음 제품군 matrix와 fallback UNKNOWN을 지원하는 후속 handler.

## 5. 수량·소비·산출 계약

```json
{
  "output_rule": {
    "mode": "configured_units",
    "unit_form": "bobbin",
    "length_m": "4000",
    "unit_count": 10,
    "quantity_basis": "per_operation",
    "schedule": "sequential_units",
    "accounting_mode": "abstract_yield"
  },
  "input_rule": {
    "acquire_scope": "per_operation",
    "consume_policy": "unknown"
  },
  "handoff_rule": {"mode": "per_output_unit"}
}
```

- configured_units: 산출 목표를 직접 지정. AL 싱글 메인에 적용.
- split_length: 원재료 길이에서 목표 단위로 분할.
- pass_through: 길이·수량 유지, 새 처리 상태로 전이.
- merge_strands: 가닥 합류; 산출 길이는 스트림/투입 길이 규칙으로 결정. 단순 합산 금지.
- fixed_mass_units: 중량 단위 산출, 길이는 미정 허용.

quantity_basis=per_operation/per_input_unit/per_lot/total_plan.
총 시나리오 생산 목표와 공정 한 작업의 산출 수량은 서로 다르다.
입력 한 번 확보하고 10개를 만드는 공정에서 매 산출마다 입력 13개를 재요청하지 않는다.
abstract_yield는 물량보존 검증 예외이며 원가·원자재 효율 지표에 경고를 붙인다.

투입 상태:
- reserve: 작업에 배정되었지만 아직 소비 전
- consume: 더는 다른 작업에서 사용할 수 없는 시점
- transfer/support: 공급 설비에 장착되어 메인 작업 동안 쓰는 관계
시점이 UNKNOWN이면 해당 handler의 실행을 막거나 승인된 시나리오 가정으로만 진행.

## 6. 잔량 계약

```json
{
  "residual_rule": {
    "mode": "carry_same_product",
    "on_product_change": "discard",
    "on_run_end": "unknown",
    "scope": "unknown",
    "physical_join_mode": "abstract_length_pool"
  }
}
```

제품1은 동일 제품 중 이월/전환 시 폐기만 확정.
실제 케이블 접속 방식이 확인된 것이 아니므로 abstract_length_pool이라고 표시.
scope=machine/product/operation/lot 중 사용자가 승인한 값이 필요.
제품5 절연의 4,000m는 잔량량만 알며 discard는 미정.
길이 폐기와 중량 폐기는 별개 지표. 가공 중 추가되는 절연/쉬스 재료 중량은 현재 모델 범위 밖.

## 7. 이동·예약·Out 정책

```json
{
  "dispatch_rule": {
    "condition": "destination_equipment_available",
    "reservation": "unknown",
    "wait_at_in_if_busy": true
  },
  "release_rule": {
    "condition": "destination_accepts",
    "block_machine_while_waiting": "unknown"
  },
  "travel_rule": {
    "mode": "unknown",
    "transport_mode": "amr",
    "duration_min": null
  }
}
```

travel mode: unknown, manual_duration, network_route, direct_feed.
direct_feed도 항상 이동시간 0이라고 확정하지 않는다. 실제 직결 선행/지연 설정 필요.
선택 설비가 이동 중 변경되는 경우 재배정 정책과 예약 취소 규칙을 명시한다.
용량 예약과 실제 운반 자원 배차는 별도 상태이다.

## 8. 그래프 계약

```json
{
  "schema_version": "1.0",
  "process_version_id": "00000000-0000-4000-8000-000000000001",
  "nodes": [
    {
      "id": "00000000-0000-4000-8000-000000000011",
      "node_key": "insulation",
      "kind": "operation",
      "step": {"operation_type": "processing", "handler_version": "1"}
    },
    {
      "id": "00000000-0000-4000-8000-000000000012",
      "node_key": "irradiation_wait_1",
      "kind": "buffer",
      "asset_id": "00000000-0000-4000-8000-000000000021"
    }
  ],
  "edges": [
    {
      "id": "00000000-0000-4000-8000-000000000031",
      "from_node_id": "00000000-0000-4000-8000-000000000011",
      "to_node_id": "00000000-0000-4000-8000-000000000012",
      "edge_kind": "material"
    }
  ]
}
```

위 예시는 구조 발췌이며 실행 가능한 전체 모델은 아니다.
operation에 시간/spec/resource가 모두 있어야 실행 가능.
FE node 좌표는 process_editor_state에 별도 저장.
batch graph PUT은 전체 유효성 검사 후 한 트랜잭션으로 변경하고 revision을 증가.

## 9. 실행 입력 스냅샷

compiler 입력은 다음을 포함해야 한다.

```text
schema_version
project_snapshot: id, name, organization scope
process_versions: frozen graph + rules + product specs
asset_revisions: frozen ports/capacities/candidate qualifications
layout: frozen network/placements or explicit manual travel rules
production_plan / arrivals / initial_wip
calendar / timezone / stopping_rule
scenario_assumptions with acknowledgments
seed / per-replication random streams
engine_version / dependency_lock_hash / code_commit
source_refs / validation_report / snapshot_hash
```

임의 외부 파일 경로나 평가 가능한 Python 문자열은 snapshot에서 금지.
실행 중 DB 현재 선속·현재 좌표를 다시 읽지 않는다.
스냅샷 내용 hash는 문서 정의 canonical JSON 직렬화로 생성. 정렬키·공백·decimal 문자열 표현을 고정.
hash 계산 대상에서 자기 hash와 생성 시각 등 비결정적 필드를 제외.

## 10. 종료·가용시간 계약

stopping_rule:
- fixed_horizon: `[0,H)` 기준, H 시각 이벤트 처리 여부를 명시.
- target_completed: 특정 완제품 milestone의 목표 보빈/길이 도달.
- drain_after_last_arrival: 마지막 입고 후 WIP 소진.
- max_events/max_wall_seconds: 안전 제한.

입고: scheduled, periodic, stochastic(분포 검증 후 후속).
생산 계획: 투입 원자재 수량과 완제품 목표를 별도 컬럼.
초기 WIP: 품목·길이·단위 수·공정 위치·처리 상태·가용 시각.
달력: 휴무/근무 외 진행 작업 정책 continuous/pause/finish_current 명시.
아직 없는 고장/수리/불량 기능은 일반 JSON에 숨겨 “지원”이라고 표시하지 않는다.

## 11. import/export

- export는 schema_version + project manifest + 참조된 설정만 포함.
- 복사/가져오기 시 ID map을 생성하고 FK 전체 변환, 코드 충돌은 사용자 해결.
- 원본 코드·원본 ID는 provenance에 보존하되 새 FK로 사용하지 않음.
- dry-run은 추가/수정/누락/충돌/UNKNOWN 보고.
- import는 idempotent external_key 또는 import_batch_id 적용.
- 실행 결과는 기본 복사 제외, 실행 기록을 복사할 때는 읽기전용 artifact로 구분.
- 승인된 생산 데이터와 fixture의 assumed 값을 섞지 않는다.


## 12. 지원 기능과 데이터 등록의 차이

운영 화면은 등록가능/검증가능/실행가능 상태를 분리한다.
예:
- kg 용량 공간 등록은 가능, 초기 item-only capacity handler에서는 실행 차단.
- 재작업 순환 graph는 저장할 수 있어도 유효한 반복 종료 규칙/handler 없으면 실행 차단.
- 신규 공정명 입력이 곧 새로운 물리 모델 지원을 의미하지 않음.
- 입고가 영구 반복되면 drain termination과 충돌할 수 있으므로 종료/입고계획 검증.
- supply 관계의 “산출12보빈”은 별도 가공 산출 복제가 아니라 원래 투입의 공급 상태가 될 수 있음.
  AL 싱글-12에 동일 item을 중복 생성하지 않는다.

## 13. 초기 수량 계획의 과잉 해석 방지

제품 정의의 “입력24개/산출9개”는 작업 구성이지 전체 생산물량이 아니다.
P05 태신선 한 작업36개가 다음 멀티신선24개를 채운 뒤12개 남을 수 있다.
이 잔여 **미투입 재고**는 태신선 가공 중량 잔량300kg과 다른 개념이다.
다음 작업 재고 매칭/입고 계획이 없으면 사용가능12개를 자동폐기하거나 원자재를 무한 생성하지 않는다.


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).



---

<a id="doc-04-api-contract"></a>

# 04. 공통 API 계약

> PROPOSED. Backend가 OpenAPI를 만들고 Frontend는 이를 기반으로 타입/클라이언트를 생성한다.
> FastAPI는 OpenAPI 기반 API 명세 생성을 제공한다. [S04](#s04)
> URL 아래의 p/v/r은 각각 project_id/process_version_id/run_id를 나타내는 설명용 표기다.

## 1. 공통 규약

- base: `/api/v1`
- 외부 business API는 project path 필수: `/projects/{project_id}/...`
- 인증 주체와 조직/프로젝트 멤버십은 서버에서 확인.
- 프로젝트 객체를 못 찾거나 접근 권한이 없으면 외부에는 동일한 404 정책을 적용할 것을 제안.
- 목록: `limit`, `cursor`, 허용된 `sort`, `q`, `status` 필터. max limit=200 초기 제안.
- 숫자 단위는 필드명과 DTO에 명시.
- 실제 시각 ISO8601 UTC, UI에서 KST 변환.
- `X-Request-ID` 응답, 사용자 입력 request ID 검증.
- 수정 응답 `ETag: "17"`; 변경 요청 `If-Match: "17"`.
  버전 누락 428, 불일치 412. 마지막 저장 승리 방식 금지.
- 실행/복사/가져오기 POST: `Idempotency-Key`.
  동일 키+동일 body는 기존 결과, 동일 키+다른 body는 409.
- validator 규칙의 결과는 단순 HTTP 성공과 분리. `/validate`는 오류 목록이 있어도 정상 검증 처리면 200.
- 별도 계약 없는 순서 의존 bulk write 금지.

## 2. 오류 응답

```json
{
  "error": {
    "code": "RUN_VALIDATION_FAILED",
    "message": "필수 실행 조건이 미정입니다.",
    "request_id": "req-demo",
    "details": [
      {
        "severity": "error",
        "rule_id": "VAL-TIME-003",
        "entity_id": "00000000-0000-4000-8000-000000000001",
        "field_path": "/timing_rule/processing/output_schedule",
        "message": "멀티신선 산출 방식이 미정입니다.",
        "resolution": "확정값 입력 또는 시나리오 가정 승인"
      }
    ]
  }
}
```

기타 코드:
PROJECT_SCOPE_MISMATCH, VERSION_IMMUTABLE, PRECONDITION_REQUIRED,
EDIT_CONFLICT, UNSUPPORTED_HANDLER, MISSING_ASSUMPTION_ACK,
NETWORK_ROUTE_NOT_FOUND, INVALID_UNIT, IDEMPOTENCY_CONFLICT, JOB_CANCEL_TOO_LATE.
프레임워크 기본 validation 오류도 위 envelope로 변환.

## 3. 프로젝트·기준정보 API

| Method | Path | 역할 / 결과 |
|---|---|---|
| GET | /me | 인증 사용자·허용 조직·프로젝트 |
| GET/POST | /projects | 권한 범위 목록 / 생성 |
| GET/PATCH | /projects/{p} | 조회 / 설정 변경 |
| POST | /projects/{p}/archive | 보관 |
| POST | /projects/{p}/clone | 복사 job 202, ID 재매핑 |
| GET/POST/PATCH/DELETE | /projects/{p}/members[/{id}] | 관리자만 역할 관리 |
| GET/POST | /projects/{p}/groups | 그룹 목록/생성 |
| PATCH | /projects/{p}/groups/{id} | 이름·부모 변경 |
| PUT | /projects/{p}/groups/{id}/assets | 매핑 일괄 교체 |
| GET/POST | /projects/{p}/assets | kind 필터, 자산 생성 |
| GET/PATCH | /projects/{p}/assets/{id} | 표시정보 수정; ETag |
| POST | /projects/{p}/assets/{id}/archive | 비활성화 |
| GET | /projects/{p}/assets/{id}/ports | IN/OUT/ACCESS |
| GET/POST | /projects/{p}/assets/{id}/revisions | 버전 조회/초안 생성 |
| GET/PATCH | /projects/{p}/asset-revisions/{id} | 설정 조회/초안 수정 |
| POST | /projects/{p}/asset-revisions/{id}/approve | 검토권한 승인 |
| GET/POST | /projects/{p}/materials | 재료 목록/생성 |
| GET/PATCH | /projects/{p}/materials/{id} | 재료 조회/수정 |
| GET/POST | /projects/{p}/products | 제품 목록/생성 |
| GET/PATCH | /projects/{p}/products/{id} | 제품 조회/표시 수정 |

자산 생성은 kind에 따라 subtype·포트를 원자 생성한다. FE가 포트를 따로 두 번 요청하지 않음.
설비군 candidate qualification 변경은 공정 새 버전에서 수행.

## 4. 공정 버전·그래프 API

| Method | Path | 의미 |
|---|---|---|
| GET/POST | /projects/{p}/products/{id}/process-versions | 목록/새 초안 |
| GET | /projects/{p}/process-versions/{v} | 상태·제품·검증 요약 |
| GET/PUT | /projects/{p}/process-versions/{v}/graph | 그래프 전체 조회/원자 저장 |
| PATCH | /projects/{p}/process-versions/{v}/steps/{step_id} | 공정 상세 수정, 전체 버전 ETag 검사 |
| GET/PUT | /projects/{p}/process-versions/{v}/editor-state | 화면 좌표, 물리 layout 아님 |
| POST | /projects/{p}/process-versions/{v}/validate | knowledge/run_template 구분 |
| POST | /projects/{p}/process-versions/{v}/submit | 검토 요청 |
| POST | /projects/{p}/process-versions/{v}/approve | 승인 |
| POST | /projects/{p}/process-versions/{v}/reject | 반려 사유 |
| POST | /projects/{p}/process-versions/{v}/clone | 새 초안 |
| GET | /projects/{p}/process-versions/{v}/diff?base_id=... | 버전 비교 |

PUT graph 규칙:
1. 권한/If-Match 확인.
2. 모든 client UUID 또는 새 node 임시 key를 검증.
3. 같은 프로젝트/버전 참조인지 검사.
4. DB 트랜잭션 안에 node/step/spec/edge/resource를 함께 저장.
5. 삭제되는 노드에 연결된 edge 처리 명시; 묵시적으로 엉뚱한 연결 생성 금지.
6. new row_version·validation summary 반환.
7. 위키 갱신 outbox 생성. 승인 정보 공개는 승인 이벤트 때만.

## 5. 시나리오·실행 API

| Method | Path | 의미 |
|---|---|---|
| GET/POST | /projects/{p}/scenarios | 목록/생성 |
| GET/POST | /projects/{p}/scenarios/{id}/versions | 버전 조회/초안 |
| GET/PATCH | /projects/{p}/scenario-versions/{id} | 입력·가정·계획 편집 |
| POST | /projects/{p}/scenario-versions/{id}/validate | 사용 자원·경로 기반 실행 검증 |
| POST | /projects/{p}/scenario-versions/{id}/approve | 가정 포함 승인 |
| POST | /projects/{p}/runs | 202, snapshot+run+job 원자 생성 |
| GET | /projects/{p}/runs | 실행 목록 |
| GET | /projects/{p}/runs/{r} | 상태·attempt·진행·종료사유 |
| GET | /projects/{p}/runs/{r}/input | 당시 입력 snapshot |
| POST | /projects/{p}/runs/{r}/cancel | 취소 요청, 실제 취소와 구분 |
| POST | /projects/{p}/runs/{r}/rerun | 동일 snapshot의 새 run |
| GET | /projects/{p}/runs/{r}/events | event_seq cursor, step/asset/item 필터 |
| GET | /projects/{p}/runs/{r}/metrics | 집계 조회, window·definition 포함 |
| GET | /projects/{p}/runs/{r}/items/{item_key}/lineage | 분할·합류·이월 |
| POST | /projects/{p}/comparisons | 승인된 run pair 비교 |
| GET | /projects/{p}/comparisons/{id} | 조건 차이·비교가능성·지표 |

실행 요청:
```json
{
  "scenario_version_id": "00000000-0000-4000-8000-000000000101",
  "seed": 42,
  "replicate_index": 0,
  "assumption_acknowledgments": ["ASM-TRAVEL-001"]
}
```

실행 응답:
```json
{
  "data": {
    "id": "00000000-0000-4000-8000-000000000201",
    "status": "queued",
    "input_hash": "실제_해시로_대체",
    "links": {"status": "/api/v1/projects/.../runs/..."}
  }
}
```

초기 진행 조회는 polling. 실제 동작 검증 후 SSE를 추가해도 됨.
target-based run은 정확한 진행률을 알 수 없으면 percent=null, 현재 시각·생산량 표시.

## 6. LLM·위키 API

| Method | Path | 의미 |
|---|---|---|
| GET | /projects/{p}/wiki | 승인 정보 기본, 권한 있는 초안 토글 |
| GET | /projects/{p}/wiki/{id} | 근거/버전 표시 |
| POST | /projects/{p}/questions | 질문, run/version 선택, 읽기전용 답변 |
| GET | /projects/{p}/conversations/{id} | 프로젝트에 고정된 대화 |
| POST | /projects/{p}/questions/{id}/feedback | 근거성 평가 |

정형 값은 API 계산/조회 결과로 답하고, 모든 수치에 source_ref 연결.
외부 모델 장애 시 실패 메시지와 일반 화면 대체 조회 제공.
확정하지 않은 분석은 fact/hypothesis로 구분.

## 7. CAD·배치 API — 후속

artifact upload init/complete → import job → candidates → mapping approval → layout draft.
`/layouts`, `/layout-versions/{id}`, `/ports`, `/network`, `/validate`, `/approve`.
직접 DWG 지원은 초기 약속 아님. DXF 또는 추출 ZIP 기준, 미지원 형상 보고.
물리 network를 route editor의 임의 노드 좌표로 덮어쓰지 않음.

## 8. API 테스트 계약

- OpenAPI snapshot diff, 변경 시 generated client 갱신.
- 허용되지 않은 enum/NaN/Infinity/음수/모호한 단위 422.
- 다른 프로젝트 UUID로 요청하면 조회/변경 모두 거부.
- 버전 충돌과 승인 직후 PATCH 거부.
- Idempotency-Key 동시 요청은 같은 run 하나 생성.
- 승인 직후 위키 인덱스가 늦더라도 SQL 도구는 올바른 버전 반환.
- 취소/실패 실행 결과를 성공으로 노출하지 않음.


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).



---

<a id="doc-05-backend-python"></a>

# 05. Python 백엔드 개발 기술서

> 선행: ERD/DTO/API 승인. 본 문서는 구현안이며 코드 실행 결과가 아니다.
> React/Python/PostgreSQL/SimPy는 요구사항. 나머지는 PROPOSED.

## 1. 권장 구성

| 영역 | 제안 | 선택 이유 / 경계 |
|---|---|---|
| HTTP API | FastAPI + Pydantic | typed DTO, OpenAPI; framework 기능 근거 [S04,S08] |
| ORM | SQLAlchemy 2.x | 테이블·트랜잭션·repository 관리 |
| migration | Alembic | 스키마 변경 추적, 생성 결과 수동 검토 [S07](#s07) |
| DB | PostgreSQL | FK·UNIQUE·트랜잭션·RLS 사용 [S01,S02] |
| simulation | SimPy 4.x 계열 | 자원·이벤트 기반 모델, exact 버전 잠금 |
| job execution | 별도 Python worker + PostgreSQL job queue | 초기 외부 브로커 없이 시작 |
| artifact | 로컬 개발 volume / 운영 object storage adapter | 원본 CAD·대형 파일을 DB에 직접 넣지 않음 |
| test | pytest, 실제 PostgreSQL 통합 테스트 | SQLite로 RLS/락 의미 대체 금지 |
| code quality | 타입 검사·format/lint·dependency lock | 도구 exact 버전 착수 시 결정 |

런타임 Python 버전은 개발자 환경을 고려해 3.12를 검토 기준으로 제안하되,
전체 의존성 호환성을 CI로 확인하고 lockfile에 정확히 고정한다. “최신”이라고 간주하지 않는다.

### 동기/비동기 선택

제안안은 API DB I/O에 AsyncSession, worker 저장에 독립적인 sync Session.
동일 Session을 concurrent task 또는 다른 process와 공유하지 않는다. SQLAlchemy도 AsyncSession을
동시 작업 간 공유하지 말고 task별로 분리하도록 설명한다. [S06](#s06)
개발팀이 sync-only API를 선택하면 ADR로 바꾸되, sync DB 호출을 async handler에서 무분별하게 직접 실행하지 않는다.

## 2. 저장소 예시

```text
apps/
  api/
    app/
      main.py
      api/v1/
      auth/
      schemas/
      services/
      repositories/
      models/
      validation/
      integrations/llm/
      integrations/storage/
      settings.py
    migrations/
    tests/
  worker/
    runner.py
    jobs/
    tests/
packages/
  domain/
    rules/
    contracts/
    units/
    errors/
  simulation/
    compiler/
    handlers/
    resources/
    logistics/
    monitoring/
    tests/
contracts/
  openapi.json
  examples/
docs/platform/
```

순환 의존성 금지:
API → service → domain/repository.
worker → domain/compiler/simulation.
simulation은 FastAPI Request, ORM Session, LLM SDK에 의존하지 않는다.

## 3. 요청 생명주기

1. 인증 token/session 확인.
2. 조직·프로젝트 멤버 권한 확인.
3. DTO 타입/단위 검증.
4. 프로젝트 범위 DB transaction 시작.
5. repository query 모두 project predicate + scope FK.
6. 업무 검증: 승인 불변, candidate/edge 일치, ETag.
7. 변경 및 audit/outbox 원자 저장.
8. commit 후 응답. 외부 인덱스/LLM 호출은 별도 job.
9. 안전한 로그에 request_id, actor, project, latency만; 민감 원문 기본 금지.

OIDC 또는 기존 인증 연동은 인증 adapter로 구현. 개발 모드의 테스트 주체는 local에서만 허용.
운영에서 사용자 지정 header만으로 admin이 되는 mock auth 금지.

## 4. 서비스 목록

- ProjectService: 생성·권한·복사·보관
- AssetService: subtype/포트 생성, 별칭, revision, archive
- ProcessService: graph 저장/검증/버전/승인
- ValidationService: knowledge/compile/run scope 검사
- ScenarioService: production/arrivals/WIP/assumptions/asset pins
- RunService: snapshot/run/job 생성, cancel, rerun
- MetricsService: 정의된 지표 계산·비교·window 필터
- WikiService: DB에서 문서 생성, manual explanation overlay
- QuestionService: 읽기전용 도구 orchestration
- CadService: 업로드·변환·mapping 검토·layout 버전
- ArtifactService: project 권한·해시·보존·다운로드

## 5. 검증 단계와 오류

V0 transport: JSON 형식, UUID, decimal, enum.
V1 integrity: 동일 프로젝트/버전 FK, 포트 및 subtype.
V2 graph: dangling edge, 시작·끝, input spec 연결, source 공급 경로.
V3 domain: 단위·투입/산출 의미·잔량·수량 basis.
V4 execution: handler 지원, 필수 용량/시간/예약/인계 조건 확정.
V5 scenario: 입고/초기 WIP, 재고 부족, horizon/target, 승인 가정.
V6 physical: network mode일 때만 좌표·연결·통행 가능 검증.

knowledge 승인은 V0~V3 구조 오류가 없어야 함.
UNKNOWN에 대한 warning은 승인 가능하지만, 사용되는 기능의 V4~V6 필수 미정은 실행 차단.
수량 추상화를 명시적으로 승인한 공정은 conservation 오류가 아니라 annotation으로 다룬다.

각 오류는 rule_id, field_path, entity_id, severity, resolution을 포함.
여러 오류를 한 번에 반환하며 첫 오류만 보여 반복 수정하게 하지 않는다.

## 6. 실행 제출 트랜잭션

- 입력은 승인된 scenario_version.
- validation이 참조한 row_version/hash가 여전히 맞는지 다시 검사.
- 필요한 공정/자산/배치/시나리오 내용을 읽어 불변 snapshot 구성.
- snapshot hash + engine_version + seed 저장.
- simulation_run + run_input_snapshot + job을 한 transaction에서 commit.
- 응답 202 후 worker가 처리.
- LLM/클라이언트가 보낸 compiled code는 실행하지 않음.

FastAPI BackgroundTasks는 같은 프로세스에서 작은 후처리에 쓰일 수 있으나 무거운 계산에는
별도 작업 처리 도구 사용이 안내된다. 이 플랫폼은 긴 SimPy 실행을 독립 worker로 분리한다. [S05](#s05)

## 7. PostgreSQL job queue 제안

`FOR UPDATE SKIP LOCKED`로 다른 worker가 점유한 job을 피하는 claim 패턴을 사용한다.
SKIP LOCKED의 일반 조회 결과 일관성 제한 때문에 큐 작업에 한정한다. [S03](#s03)

절차:
1. 짧은 transaction에서 queued/available job 1개 선택 및 lease 생성.
2. run_attempt와 fencing_token 생성 후 commit. 실행 동안 DB row lock 유지 금지.
3. 별도 child process에서 compile/run. API worker와 메모리 공유 금지.
4. supervisor가 heartbeat·취소·wall timeout 감시.
5. batch event flush 시 attempt/fencing token 검증.
6. 성공 후 결과와 run.selected_attempt_id 확정.
7. lease 만료 실행은 stale 처리. 이전 worker의 늦은 쓰기는 fencing으로 거부.
8. queue transport 실패 재시도와 simulation retry는 분리.
9. 동일 snapshot 재실행은 새 attempt; 미지원 resume를 가능하다고 광고하지 않음.

큐가 커지면 broker 기반 구현으로 교체 가능한 JobDispatcher interface를 둔다.
초기부터 여러 큐 제품을 동시에 도입하지 않는다.
작업별 project scope, 사용자 quotas, max events/items/wall-time 제한 필수.

## 8. 취소·실패·복구

상태:
queued → running → completed
queued → cancelled
running → cancel_requested → cancelled
running → failed / stalled / limit_reached

- UI cancel 버튼은 “취소 요청됨”을 먼저 표시.
- child process 종료 전 확보 중인 artifact 처리, attempt 상태 저장.
- OOM/프로세스 종료로 마지막 이벤트를 못 기록했으면 로그 완전성 false.
- stale worker는 동일 run을 completed로 되돌리지 못함.
- 이벤트 commit은 UNIQUE(attempt,event_seq)로 중복 방지.
- 초기 checkpoint resume는 미지원. rerun은 시작점부터 재실행.

## 9. 성능 원칙

- simulation 이벤트마다 HTTP나 DB 조회하지 않는다.
- 입력 snapshot은 한 번 읽고 엔진 내부 상태로 운영.
- event buffer는 크기/시간 기준 batch 저장, buffer limit 초과 시 정책 명시.
- 거대한 CAD를 API process에서 파싱하지 않는다.
- 표·이벤트 조회는 cursor pagination.
- run 진행은 time/target/terminal 상태로 알리며 허위 100% 금지.
- DB/CPU/메모리 성능 목표는 측정 후 확정. 초깃값을 성능 보장으로 제시하지 않음.

## 10. 배포·환경

환경 예시:
DATABASE_URL, AUTH_ISSUER, AUTH_AUDIENCE, ARTIFACT_BACKEND,
WORKER_MAX_WALL_SECONDS, WORKER_MAX_EVENTS, LLM_PROVIDER, LLM_ENABLED.
.env.example에는 변수 이름과 가짜 값만, 실키 금지.
API/worker/migration DB 역할 분리. migration은 배포 단계 1회.
readiness는 DB/schema 호환 확인, liveness는 프로세스 상태.
object storage 없는 local 모드는 개발용임을 표시.

## 11. 백엔드 완료 기준

- ERD 복합 FK/불변/RLS 부정 테스트 통과
- 생성 API로 설비 IN/OUT이 원자 생성
- graph round-trip 및 최신 제품 정정 보존
- 실행 snapshot으로 master 없이 compile
- 동일 입력/seed/엔진에서 이벤트 재현 테스트 통과
- 중복 실행/취소/worker crash 테스트 통과
- API OpenAPI와 실제 응답 일치
- 계산된 지표 정의·단위·기간·입력 hash 제공


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).


## 12. 단계별 데이터 전달물

DB 담당 → BE:
- ERD 승인 버전, 실제 migration, 제약/enum/null 규약, seed fixture.
BE → FE:
- 저장한 OpenAPI 파일, 생성 client 버전, 요청/응답 examples, 오류 rule_id 사전.
BE → engine:
- frozen snapshot JSON fixture, schema_version, 검증된 단위/assumptions.
engine → metrics:
- event schema와 state 전이, definition version, partial completeness.
metrics → LLM:
- 제한된 summary DTO, unit/window/source snapshot, quality warnings.
각 전달물에 commit/hash를 기록하고 API팀이 임의로 필드를 바꾼 뒤 FE에 알리지 않는 일을 방지한다.



---

<a id="doc-06-frontend-react"></a>

# 06. React 프런트엔드 개발 기술서

> 선행: 02 ERD → 03 DTO → 04 API.
> UI는 DB의 모든 테이블을 그대로 한 화면씩 노출하지 않는다.
> React는 사용자 선택, TypeScript와 이하 라이브러리는 제안이다.

## 1. 기술 구성

| 영역 | 제안 | 비고 |
|---|---|---|
| 앱 | React + TypeScript | 타입 검증과 컴포넌트 분리 |
| 빌드 | Vite | 개발/빌드 도구로 채택 제안 [S10](#s10) |
| 서버 상태 | TanStack Query | project/version 포함 query key [S11](#s11) |
| 공정 그래프 | React Flow (@xyflow/react) | node/edge/handle 편집 [S12](#s12) |
| 로컬 편집 상태 | React reducer 우선 | 복잡해질 때 별도 store ADR |
| 폼 | typed form + 서버 검증 매핑 | 특정 폼 제품은 아직 고정하지 않음 |
| 라우팅 | 경로 기반 router | /projects/:id 하위 일관된 scope |
| 테스트 | Vitest + browser E2E 도구 | Vitest 근거 [S18](#s18), E2E 제품 선택 별도 |
| 스타일 | 공통 디자인 토큰·접근성 컴포넌트 | 라이선스 검토 후 UI kit 선택 |

exact 버전과 Node 버전은 착수 시 호환표 확인 및 lockfile 고정.
플랫폼 기술서가 최신 package 버전을 자동 선택하라는 의미는 아니다.

## 2. 폴더 제안

```text
src/
  app/           # router, providers, auth bootstrap
  generated/     # OpenAPI 생성 타입/클라이언트, 직접 수정 금지
  features/
    projects/
    assets/
    products/
    processes/
    scenarios/
    runs/
    wiki/
    questions/
    layouts/
  shared/
    api/
    units/
    components/
    hooks/
    validation/
  test/
```

feature 간 직접 DB shape 공유 대신 공통 DTO/adapter.
서버 상태·로컬 폼·선택 상태를 분리하고 중복 상태를 줄이는 방향으로 설계한다.
React 공식 지침도 모순·중복·불필요한 상태를 줄일 것을 설명한다. [S09](#s09)

## 3. 화면 목록

| 화면 | 핵심 기능 | 우선 |
|---|---|---|
| 프로젝트 목록/생성 | 범위·사업체·복사·보관 | A |
| 프로젝트 홈 | 제품·설비·미정·최근 실행 요약 | A |
| 자산 목록 | 설비/공간/도킹 필터, 코드/이름, 그룹 | A |
| 자산 상세 | IN/OUT, 버전별 용량·정책, 별칭, 미정 | A |
| 제품 목록/상세 | 규격·원자재·완제품 판정 | A |
| 공정 표 편집 | 투입·산출·시간·설비·다음 위치 | A |
| 공정 그래프 편집 | IN/OUT handle, 분기·합류·재방문 | A2 |
| 검토/승인 | 버전 diff, 검증 오류, 승인/반려 | A |
| 위키·질문 | 근거·버전·초안 구분 | B |
| 시나리오 작성 | 입고·WIP·물량·근무·가정·버전 선택 | C |
| 실행 목록/상세 | 큐·실행·취소·오류·로그 | C |
| 결과·비교 | 지표·단위·기간·조건 차이 | C/D |
| CAD/배치 | 배경 도면·매핑·포트·통로 편집 | E |

초기 입력은 표 편집을 먼저 완성하고 드래그 그래프를 후속으로 붙인다.
보기만 가능한 예쁜 그래프를 구현하고 구조화 저장을 나중에 억지로 맞추지 않는다.

## 4. 프로젝트 격리

모든 목록·상세 query key:
```typescript
["project", projectId, "processVersion", versionId, "graph"]
["project", projectId, "run", runId, "metrics", filters]
```

- project 전환 시 요청 cancel, 이전 cache 표시 금지, 로컬 unsaved draft 처리.
- 이전 project ID를 closures/form default에 남기지 않음.
- URL의 project_id와 현재 context 불일치 시 새 scope로 reset.
- 다른 project의 run/version ID를 붙인 URL은 서버 거부를 그대로 표시.
- 대화창도 project에 고정. 프로젝트 전환 시 이전 질문 context 재사용 금지.
- project color/breadcrumb를 상시 표시하여 운영자 오입력 방지.

## 5. 자산 편집

설비:
- 이름/표시 코드/유형/모델/그룹.
- IN/OUT은 필수 고정 포트, UI에서 일반 edge처럼 삭제 불가.
- 포트 위치 unknown 표시. 미배치라도 생성 가능.
- 용량 unknown/finite/unlimited/not_allowed 선택.
- 설비 가용성·reservation·OUT blocking 정책은 설정 버전 내 관리.

저장공간:
- storage/dock 구분, alias.
- 저장 용량과 접근 위치를 다른 섹션에 표시.
- ST-021/022 도킹이 있다는 이유로 적재 용량을 자동 무제한 처리하지 않음.

코드 변경은 자산 연결을 끊지 않음. ID는 UI에서 읽기전용.
기존 데이터에 새 코드 부여는 “정렬 변경”과 별도 기능으로 둔다.

## 6. 공정 편집

표 열:
순서/공정명/설비후보/투입길이·중량·수량·가닥/산출 규격·수량/
선속 또는 시간/준비 trigger/다음 위치/이동/잔량/확인상태.

정수 수량과 decimal 길이 입력 컴포넌트를 분리.
m/min vs min/unit vs min/reference-length 모드 선택으로 모호한 단위 텍스트 줄임.
UNKNOWN 필드는 빈 값만 보이지 않고 “미정” 배지 표시.
0분 입력을 삭제하지 않음. 사용자가 field를 clear하면 unknown 사유 요청.
그룹 후보와 선택된 특정 설비를 명확히 구분.

산출 예시:
- 길이 분할: 2,000m → 1,000m × 2
- 지정 산출: 투입13개 → 4,000m × 10, 추상화 경고
- 유지: 입력 규격 참조, 수량1
- 보빈별 인계와 전체 인계를 별도 선택

## 7. 그래프 편집

node:
- operation: IN/OUT handle, 선택 설비군, 처리 모드 요약
- buffer: ST 코드·용량·확인상태
- source/sink: 시작·종료
- join: 전체 준비 조건
- milestone: 완제품/검사/적재 상태

edge:
- material: 이동/대기 정책
- supply: 직결 공급, 일반 운반과 색상·범례 구분
- precedence: 완료 의존성 점선

동일 EQ-036을 여러 operation node에 보여도 asset_id는 동일.
ST-012 재방문 노드도 동일 space asset_id, 서로 다른 step context.
그래프의 좌우 배치는 공장 실제 방향이 아니다.
React Flow position을 port_placement에 복사하는 기능 금지.
save는 graph PUT 한 번, dangling edge 임시 편집 허용하되 서버 승인 시 검사.
키보드 접근/표 대체 편집 제공. 줌/큰 그래프 필터/제품별 보기 지원.

## 8. 동시 편집·승인

서버 row_version/ETag 유지.
다른 사용자가 수정했으면 자동 덮어쓰기 금지, diff/reload/copy draft 선택.
저장 성공 전 승인 버튼 중복 실행 차단.
approved route는 read-only, “복사하여 수정” 동작.
인증 editor라고 곧 reviewer가 되는 것은 아님.
서버 validation field_path를 그래프 노드와 폼 필드로 연결.
warning과 error, 실행 차단과 지식 승인 가능을 다른 배지로 표시.

## 9. 시나리오·실행

Wizard:
1. 제품/공정 승인 버전 선택.
2. 자산 revision·배치 version pin.
3. 투입 물량/입고 주기/초기 WIP.
4. 근무·실행 기간/목표/seed.
5. UNKNOWN 해결: 실제 입력 vs 가정.
6. validation report 확인.
7. 가정 목록 개별 승인 및 실행 요청.

명시 가정 예:
“테스트에서만 운반시간 0분”, “검증용 EQ-034 하나 사용”.
마스터를 자동 수정하지 않는다.
pending/running/cancel_requested/cancelled/failed/stalled/limit_reached/completed 구분.
retry POST는 항상 idempotency key 관리, 브라우저 재시도 중복 실행 방지.

## 10. 결과 화면

- 생산 완료/검사 완료/적재 완료 보빈 수·길이 별도.
- 가동률은 기간/분모/상태 포함 여부 보여 줌.
- 길이 폐기와 중량 폐기 분리.
- abstract_yield 작업 포함 시 원자재 효율 신뢰 경고.
- 이벤트의 sim_time_min과 server timestamp 분리.
- incomplete/stalled run에도 부분 결과 조회 가능하나 성공 배지 금지.
- compare는 입력 diff 먼저, 지표 차이 다음.
- 질문 버튼은 선택 run ID/metric context 전달; 전체 event payload 전송 금지.

## 11. 위키·LLM

- 답변마다 project/version/run 근거 표시.
- 승인된 데이터만 기본, 초안 포함은 권한·명시 토글.
- 모르는 답은 미정으로 표시. 자동값 채우기 버튼 금지.
- 도구 실패·모델 장애·권한 거부를 서로 다른 상태로 표시.
- 문서에서 생성한 값과 수동 설명을 구분.
- LLM 출력 HTML/Markdown은 안전 렌더링; 임의 script/iframe 실행 금지.

## 12. CAD 후속

- 원본 좌표와 화면 좌표 adapter, 모델 단위 표시.
- CAD에서 찾은 위치는 candidate 배지.
- IN/OUT 방향 제안은 사용자가 확인하기 전 actual로 저장 금지.
- 공간 polygon/통로 graph/설비 footprint를 레이어로 분리.
- 팬·줌·선택 좌표·원본 entity path·증거 보기.
- 수백만 원시 DXF 객체를 React 컴포넌트로 한꺼번에 렌더링하지 않음.

## 13. 프런트엔드 인수 기준

- [ ] project 전환 cache 누출 없음
- [ ] 표↔그래프 round-trip 값/관계 일치
- [ ] known0/unknown/unlimited 구분 보존
- [ ] 1,000m/보빈과 1,000m/min 혼동 방지
- [ ] 같은 설비 재방문 표현 정상
- [ ] 승인 불변·ETag 충돌 표시
- [ ] 역할별 버튼 숨김과 서버 거부 모두 테스트
- [ ] run polling 재접속/취소 상태 정확
- [ ] DB enum 미지원 값에 안전한 오류 표시
- [ ] 한국어·영문 코드만 표시, 잘못 생성된 한자/일본어 없음


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).



---

<a id="doc-07-simulation-engine"></a>

# 07. SimPy 실행 엔진·정확성 계약

> PROPOSED. 실행 입력은 03의 snapshot. 사용자 공정은 08, unresolved는 13.
> 시뮬레이션은 예측 모델이며 생산 제어 시스템이 아니다.

## 1. 책임 분리

DB: 상태·버전·계획·로그 보관.
compiler: DTO 검증, 참조 해석, 단위 통일, handler 구성.
SimPy: 가상 시간의 자원·이벤트 처리.
metrics: 정의된 이벤트로 수치 계산.
LLM: 결과 조회/설명. 계산·실행 의미를 결정하지 않음.

SimPy는 Resource/Store/Container와 이벤트 기반 대기를 제공한다.
이 프로젝트의 규칙·그래프·예약·생산 단위 해석은 우리가 구현할 영역이다. [S13,S14]
“공정 JSON을 SimPy가 자동 실행”하는 구조가 아니다.

## 2. compiler 단계

1. schema_version 지원 확인.
2. snapshot hash/프로젝트 scope/버전 상태 확인.
3. 모든 사용 자산·포트·공간·edge reference resolve.
4. 숫자·시간·용량·가정 승인 검증.
5. handler registry에서 operation_type+handler_version 선택.
6. 후보 자원·물질 입출력·합류/인계 컴파일.
7. logical flow와 physical movement 연결.
8. invariant 및 지원 capability 검사.
9. RuntimeModel 생성. 이후 DB current state 조회 없음.

handler 초기 범위:
- pass_through_length
- split_length
- output_units_by_time
- configured_yield
- supply_delay
- inspection
- transport_manual
- network_transport는 후속

실제 이름은 schema에 확정하되 임의 `eval`, Python 코드 문자열, LLM 생성 코드 실행 금지.

## 3. 실행 객체

- WorkItem: item_id, product_version_key, lot, form, length_m/weight_kg, material_state, location, reserved_by.
- Operation: op_id, step_key, input reservations, output target, asset reservations, state.
- EquipmentRuntime: asset_id, availability, exclusive state, request queue, current setup family.
- BufferRuntime: owner asset/port, occupancy, pending puts/gets, reservations.
- ResidualPool: scope key, product, length, source lineage, disposal policy.
- TransportTask: source/destination, selected mode/resource, reserved slots, travel state.
- RuntimeContext: Environment, random streams, event sink, limits, snapshot.

작업물은 m당 객체가 아니라 보빈/롤/다발 또는 명시적 잔량 객체.
주문량·보빈 수가 커질 때 batch 생성도 지원하지만 보빈별 인계 이벤트를 없애지 않는다.

## 4. 시간과 산출 이벤트

선속 순차 산출: unit_duration = output_length / speed.
단위당 시간: unit_duration = duration_min.
준비시간과 대기시간은 trigger에 따라 별도 처리.
생산 중 outage/calendar 지원 여부는 명시.

예:
- AL 싱글 메인 4,000m/32 = 125분/보빈. 이상 조건이면 t=125,250,...,1250에서 10개 산출.
- 제품6 절연 1,000m/30 = 33.333...분마다 1개, 2개 합계 66.666...분.
- 10보빈 총 시간을 한 번 기다린 뒤 일괄 생성하는 구현은 per_output_unit 인계에 부적합.
- total_batch 인계라면 개별 내부 완료와 외부 가용 이벤트를 분리할 수 있다.

멀티신선처럼 여러 스트림은 별도 계산:
per_stream parallel 12개 × 40,000m @100이면 각 스트림 400분(준비 제외).
aggregate/순차 처리이면 전체 480,000m @100 = 4,800분.
이는 **서로 다른 가정의 설명 예시**이며 제품4의 실측 시간 확정이 아니다.
해당 규칙이 미정인 상태에서 둘 중 하나를 자동 선택하지 않는다.

## 5. 투입 확보·소비·분할

1. 필요한 투입 spec별 작업물을 선택한다.
2. operation 단위 원자 예약; 부족하면 일부만 소비하지 않음.
3. 가용 설비 및 목적지 정책과 조정.
4. 정의된 시점에 consume/attach.
5. 산출마다 새 item 또는 상태 전환/분할로 trace.
6. 잔량 처리, 작업 완료, 예약/설비 해제.

재료가 여러 가닥이면 합계 길이를 제품 길이로 계산하지 않는다.
configured_yield는 입력 확보 한 번 후 지정 출력 생성, 반복 투입은 새로운 operation.
13→10의 abstract_yield는 lineage 관계는 남기되 physical conservation metric에 사용하지 않는다.

가중치 없는 모호한 parent-child 링크를 재료 질량의 정확한 비율처럼 보여주지 않는다.
split_length는 부모 남은 길이 감소와 자식 생성이 원자적으로 일어나야 한다.
실패/취소 시 이미 만들어진 output과 아직 확보 중인 input을 구분해 기록.

## 6. 설비 선택과 예약

실제 설비마다 Resource를 구성한다. 같은 asset_id는 run에 한 번 생성.
여러 후보 중 선택은 FIFO/우선순위/최초가용 등의 설정이며 후보 미확정은 실행 차단.
동시 확보 설비는 allocator가 전체 확보를 조정, 각 공정이 임의 순서로 하나씩 쥐고 대기하지 않게 한다.

`AllOf`는 이벤트 완료의 결합이지 여러 자원을 원자적으로 확보하는 allocator가 아니다. [S14](#s14)
AL line의 준비 완료와 설비 점유 생명주기는 분리:
싱글-1 가공 종료가 메인 시작조건이라는 사실과 메인 중 싱글-1 설비를 계속 점유하는지는 별개다.

reservation:
- reserve_on_dispatch: 출발 전에 자원/slot 예약; transport 동안 RESERVED_TRAVEL 상태.
- no_reservation: 출발 당시 조건만 확인; 도착 시 busy면 IN 대기.
- unknown: 특정 scenario 선택 필요.

예약한 채 운반 자원을 기다려 비효율이 생길 수 있으므로 RESERVED를 PROCESSING에 합치지 않는다.
전체 운반/설비/공간 lock 순서와 취소 시 해제 정책 테스트 필수.

## 7. IN/OUT와 blocking

IN:
- 구조상 항상 존재.
- capacity not_allowed이면 가공에 바로 인계 가능한 handshake만 허용.
- finite이면 slot 확보 후 이동/입고.
- busy 도착 시 대기 허용 규칙과 capacity가 모순이면 실행 전 검증.

OUT:
- machine_hold_until_departure: 배출까지 설비 점유 유지.
- release_after_out_storage: OUT에 놓을 수 있으면 설비 해제; buffer가 차면 생산 완료 후 막힘.
- output_transfer_only: 별도 저장 없이 다음 지점과 직접 인계.
- 정책 unknown은 필수 실행 질문.

Store는 객체 보관 수용량에 적합하지만 kg/m2 용량은 별도 capacity controller가 필요하다. [S13](#s13)
0 용량 Store를 만들어 handshake를 흉내내지 않는다.
OUT 슬롯 하나와 생산중 자재 하나를 같은 물량으로 중복 집계하지 않는다.

## 8. 이동

수동시간 모드와 네트워크 모드를 동일 TransportService interface로 제공.

manual:
- 거리 없어도 명시적인 duration으로 실행 가능.
- 0분은 사용자가 승인한 가정일 때만 허용.
- 운반자원이 미정인데 무제한으로 해석하지 않음. 시나리오 가정 기록.

network:
- from selected equipment OUT / space ACCESS
- port-network attachment
- 허용 mode와 directed edges
- 경로 거리, 속도/상하차/배차 대기
- destination IN/ACCESS

첫 단계는 혼잡 없는 경로시간 계산; 구간 용량/교차로 예약은 추가 handler.
유클리드 직선을 실제 통로 이동거리로 보고하지 않음.
ST-020→ST-021 지게차 후 AMR 전환은 두 task, 무조건 한 AMR 이동으로 묶지 않음.

## 9. 이벤트 표준

공통:
project_id, attempt_id, event_seq, sim_time_min, event_type, operation_id,
step_key, asset_key, item_key, source/destination, quantities, reason, definition_version.

최소 event:
- MATERIAL_ARRIVED, INPUT_RESERVED, INPUT_CONSUMED
- DISPATCH_REQUESTED, DISPATCH_STARTED, ARRIVED_AT_IN
- SETUP_STARTED/FINISHED, PROCESS_STARTED, OUTPUT_UNIT_READY, PROCESS_FINISHED
- BUFFER_ENTERED/LEFT, OUT_BLOCKED/UNBLOCKED
- RESIDUAL_CREATED/CARRIED/DISCARDED
- INSPECTION_STARTED/FINISHED
- MILESTONE_REACHED, RUN_TERMINATED

상태시간은 exclusive asset states 기준:
IDLE, RESERVED, SETUP, PROCESSING, BLOCKED, DOWN, OFF_SHIFT.
IN 대기는 item 상태이며 설비 상태와 별도로 기록.
“자재 부족”과 “순수 idle”을 세분할 경우 reason 필드.
관측할 대상·시점·저장 방식을 미리 정하는 것이 SimPy 계측 가이드의 핵심이다. [S16](#s16)

## 10. 결과 지표

| 지표 | 정의 초안 |
|---|---|
| 생산 완료량 | 제품 completion milestone에 최초 도달한 산출 item 수 및 길이 |
| 검사 완료량 | 검사 완료 item 수 및 길이 |
| 적재 완료량 | 지정 sink 도달 item 수 및 길이 |
| throughput | 지정 완료량 / 관측 기간; 분모 단위 표시 |
| lead_time | 완료 시각 - 시나리오가 정의한 시작 시각(입고/출고 등) |
| in_wait | PROCESS_STARTED - ARRIVED_AT_IN, setup 포함 여부 별도 |
| transport_wait | DISPATCH_STARTED - DISPATCH_REQUESTED |
| utilization | PROCESSING 시간 / 지정 eligible calendar 시간 |
| occupancy | buffer occupancy 시간적분 / 관측 시간 |
| WIP | 미완료 item, m, kg 별도 |
| loss | 길이 폐기 m, 중량 폐기 kg 각각 |
| blocked_time | 배출 불가로 설비가 BLOCKED인 시간 |

분모가 0이면 null/not_applicable, 0%나 Infinity 금지.
여러 공정 생산량을 합산해 최종 생산량으로 표시하지 않는다.
중간 보빈에서 최종 보빈으로 분할되면 completion count는 최종 item 기준.
미완료 run은 observed/censored 결과로 표시.
무한 작업자 검사라도 각 보빈에 10분 경과 필요, 동시 검사는 허용.

## 11. 종료와 교착 진단

SimPy `run()`은 이벤트 소진 시 종료하며, 숫자 until=H는 H 시각 이벤트를 처리하지 않는 경계를 갖는다. [S15](#s15)
본 엔진의 fixed horizon은 `[0,H)`로 정의하고 UI/metric에 명시한다.
end-inclusive 옵션을 도입하려면 경계 검증 후 별도 계약으로 확장.

- event queue empty + 목표 달성 → completed
- event queue empty + WIP/미완료 목표 → state=stalled, 진단된 termination_reason을 별도 저장(예: INSUFFICIENT_INPUT)
- future arrivals 존재 → 단순 starvation일 수 있으므로 즉시 deadlock 단정 금지
- calendar/monitor event만 무한 발생 → progress watchdog, event cap으로 진단
- 안전 제한 종료 → limit_reached, 성공 아님
- cancellation → cancelled, 남은 WIP/로그 완전성 표시

“진행 없음 N분”만으로 공정이 길다는 이유로 deadlock 처리하지 않는다.
실행 대기 그래프와 미래 가용 이벤트를 함께 진단한다.

## 12. 재현성과 검증

같은 snapshot/hash, engine version, dependency lock, seed, tie-break order면 재현되도록 설계.
resource 후보/동시 이벤트 정렬은 안정된 UUID 또는 snapshot 순서로 명시.
각 확률요소에 독립 random stream; 글로벌 random 사용 금지.
엔진 변경 후 같은 seed라도 같은 결과를 보장한다고 주장하지 않음.
통계 비교는 동일 조건 반복 실행과 분산/불확실성 보고를 후속으로 구현.

실행 모델에 대해 모든 장비의 물리 정확도를 보장하지 않는다.
현재 입력에는 abstract yield와 UNKNOWN이 있으므로 capability/assumption 보고서를 결과에 함께 제공.


## 13. 작업 중 공유 자원의 잠금 구간

하나의 operation이 여러 보빈을 산출할 때 설비를 언제 해제하는지는 별도 정책이다.
hold_for_operation이면 모든 설정 산출이 끝날 때까지 점유,
release_per_output_unit이면 보빈마다 해제 후 재배정.
사용자 자료의 “보빈별 인계”는 downstream 가용시점이지 설비 재배정 정책 확정이 아니다.
현재 사실로 전자를 자동 적용하지 말고 시나리오 가정으로 명시한다.
제품전환 판단은 실제 선택된 설비의 직전 작업 제품/교체군 기준으로 기록한다.
공정상 절연과 쉬스가 같은 설비를 사용할 때 교체시간0이라는 입력 외에
추가 교체 matrix를 임의로 가산하지 않는다.


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).



---

<a id="doc-08-catalog-processes"></a>

# 08. 사용자 기준정보·제품 6종 — 인계용 최신 정리본

> 출처: 이 대화에서 사용자가 제공한 공정과 후속 정정.
> 모든 제품 공정은 `draft`. 설비/공간의 존재·개수는 등록된 기준정보다.
> sample project code `DEMO-WIRE`, 제품 코드 P01~P06은 개발 인계용 제안이다. 사용자 기존 코드라고 주장하지 않는다.
> 제품6까지가 최신이며 이전 도식/표의 잘못된 길이·수량을 seed로 사용하면 안 된다.

## 1. 데이터 규모와 적용 범위

- 설비 96대: 실리콘12, CU/공용76, AL8.
- 저장/대기/도킹 22곳.
- 제품 6종.
- 설비별 실제 IN/OUT·좌표·통로·용량·개별 호기명은 미정.
- EQ 범위는 각각 한 대씩 펼쳐 저장. 공정에는 자원 후보로 연결.
- 제품명에 AL이 들어가도 실리콘 제품3은 AL 신선·집합 경로를 거치지 않는다.
- 공간 ID는 실리콘 편조 공간 삽입 이후 최신 번호다. 옛 ST 번호는 사용 금지.
- 공정에 미연결: EQ-021~031(11대), EQ-037~038(2대), ST-015.
- ST-010은 제품6에서 사용되므로 더 이상 미사용 공간이 아니다.
- 위 포함 대수는 설비군 후보 기준, 모든 호기의 실제 사용 가능 확정은 아님.

## 2. 설비 목록

| ID 범위 | 설비명 | 대수 | 분류 | 비고 |
|---|---|---:|---|---|
| EQ-001 | 실리콘 절연 압출기 | 1 | 실리콘 | 제품1~3 최초 압출 |
| EQ-002 | 실리콘 쉬스 압출기 | 1 | 실리콘 | 제품1~3 쉬스 |
| EQ-003~EQ-010 | 실리콘 편조기 | 8 | 실리콘 | 개별 사용 가능 호기 미정 |
| EQ-011~EQ-012 | 실리콘 테이핑기 | 2 | 실리콘 | 개별 사용 가능 호기 미정 |
| EQ-013 | CU 태신선기 | 1 | CU | 제품5 |
| EQ-014 | CU 멀티신선기 | 1 | CU | 제품5 |
| EQ-015~EQ-020 | CU 연선기 | 6 | CU | 제품5; 제품별 조합 가능 |
| EQ-021~EQ-030 | CU 집합기 | 10 | CU | 현재 6종 경로에는 미사용 |
| EQ-031 | CU 튜블라 | 1 | CU | 현재 6종 경로에는 미사용 |
| EQ-032~EQ-033 | 절연 압출기 | 2 | 공용 | CU·AL 제품 공용 |
| EQ-034~EQ-035 | 쉬스 압출기 | 2 | CU | 쉬스 및 CU 도체 상품 절연 수행 |
| EQ-036 | 조사기 — 보빈용 | 1 | 공용 | 제품4·5·6, 1차/2차 동일 실물 |
| EQ-037~EQ-038 | 조사기 — 다발용 | 2 | 공용 | 현재 6종 경로에는 미사용 |
| EQ-039~EQ-080 | CU 편조기 | 42 | CU | 제품5·6 |
| EQ-081~EQ-084 | CU 테이핑기 | 4 | CU | 제품5; 제품6에는 없음 |
| EQ-085~EQ-088 | 재권취기 | 4 | 공용 | 제품4·5·6 |
| EQ-089 | AL 멀티 신선기 | 1 | AL | 제품4 |
| EQ-090~EQ-093 | AL 집합기(더블) | 4 | AL | 제품4 |
| EQ-094 | AL 집합 싱글-1 | 1 | AL | 선행 가공 후 메인 직결 |
| EQ-095 | AL 집합 싱글-12 | 1 | AL | 12가닥 공급, 120분 대기 |
| EQ-096 | AL 집합 싱글 | 1 | AL | 메인, 지정 산출 수량 |


### 연계 그룹

GRP-001은 EQ-094/095/096의 AL 싱글 집합 설비 관련 그룹.
물리적으로 하나의 라인이지만 제품4의 최신 설명은
“싱글-1 별도 선행 작업 후 직결, 싱글-12 120분 대기 후 공급, 메인 지정 산출”.
세 설비가 시작부터 끝까지 같은 속도로 무조건 동시 점유한다고 하드코딩하지 않는다.
메인 중 feeder 점유/연속 공급의 상세는 OPEN-004 참조.

CU 연선/집합/튜블라는 제품에 따라 세트 가능, 현재 6종에는 구체적 조합 없음.

## 3. 공간 목록

| ID | 기준 명칭 | 용도·주의 |
|---|---|---|
| ST-001 | 원자재 보관 공간 | 실리콘 원자재·도체 상품 원자재, ST-005와 별도 |
| ST-002 | 실리콘 압출 대기 공간 | 실리콘 압출 전 |
| ST-003 | 실리콘 쉬스 압출 완료 대기 공간 | 실리콘 쉬스 완료 후 |
| ST-004 | 실리콘 편조 대기 공간 | 실리콘 압출 후 편조 전 |
| ST-005 | CU 도체 원자재 보관 장소 | ST-001과 별도 |
| ST-006 | CU 멀티신선 대기 장소 | 태신선 후 멀티신선 전 |
| ST-007 | CU 연선 대기 장소 | CU 연선·집합 구역 대기 |
| ST-008 | 압출 대기 공간 — 800파이용 | 제품4·5; ST-009·010과 인접 3구역 |
| ST-009 | 압출 대기 공간 — 1050파이용 | 제품5·6; 쉬스 압출 전에도 사용 |
| ST-010 | 압출 대기 공간 — 1250파이용 | 제품6 최초 절연 전 |
| ST-011 | 조사 대기 공간 | 1차/2차 구분은 공정 상태 |
| ST-012 | 조사 완료 대기 공간 | 후속 편조/재권취는 제품·단계에 따름 |
| ST-013 | 편조기 대기 공간 | CU 편조기 42대용 |
| ST-014 | 검사 대기 공간 | 제품4·5·6 |
| ST-015 | 파렛트 적재 공간 — 다발용 | 현재 6종 경로에는 미사용 |
| ST-016 | 파렛트 적재 공간 — 보빈용 | 제품4·5·6 검사 후 |
| ST-017 | AL 원자재 보관 공간 | AL 멀티신선 대기 |
| ST-018 | AL 집합 대기 공간 | AL 더블 집합 전 |
| ST-019 | AL 집합 싱글 대기 공간 | AL 싱글 대기 공간 별칭 |
| ST-020 | AL 집합 완료 대기 공간 | AL 싱글 완료 적재 공간 별칭 |
| ST-021 | AMR 도킹 위치 | AL 집합 이후, ST-022와 별도 |
| ST-022 | CU 테이핑 후 AMR 도킹 위치 | 제품5 테이핑 후, 제품6 편조 후도 사용; 이름 일반화 제안 미승인 |


모든 공간 용량/좌표는 UNKNOWN. 800/1050/1250은 사용자 구역 표기다.
보빈 직경 mm라고 해석하는 것은 별도 확인 대상.
ST-021/022는 운반 인계 지점이며 적재 용량·수용 방식 미정.
ST-022 이름을 “CU 공정 후 AMR 도킹 위치”로 일반화하는 제안은 있으나 명칭 변경 승인 없음.
CAD의 추가 도킹 표기는 ST-023으로 등록하지 않았다.

## 4. 제품1~3 — 실리콘

| 코드 | 제품명 | 원자재 기본 단위 | 최초 압출 후 | 쉬스 후 |
|---|---|---|---|---|
| P01 | 실리콘_일반_태선(CU)_도체상품 | 2t 롤, 3,000m | 1,000m × 3보빈 | 300m × 10보빈 / 1롤분 |
| P02 | 실리콘_복합_태선(CU)_도체상품 | 2t 롤, 4,000m | 1,000m × 4보빈 | 500m × 8보빈 / 1롤분 |
| P03 | 실리콘_복합_태선(AL)_도체상품 | 2t 롤, 5,000m | 1,000m × 5보빈 | 500m × 10보빈 / 1롤분 |

공통 경로:
ST-001 → ST-002 → EQ-001 → ST-004 → 선택 실리콘 편조기
→ 선택 실리콘 테이핑기 → EQ-002 → ST-003 → 검사.

| 단계 키 | 공정 | 설비 | 산출/변환 | 속도/시간 |
|---|---|---|---|---|
| INSULATE | 절연 압출 | EQ-001 | 롤을 1,000m 보빈으로 분할 | 20m/min |
| BRAID | 실리콘 편조 | EQ-003~010 | 길이 변화 없음 | 1.5m/min |
| TAPE | 실리콘 테이핑 | EQ-011~012 | 길이 변화 없음 | 20m/min |
| SHEATH | 쉬스 압출 | EQ-002 | P01 300m, P02/P03 500m로 분할 | 15m/min |
| INSPECT | 검사 | 자원 미정 | 최종 보빈 검사 | 10분/보빈 |

- 최초 압출 “실리콘 압출기”는 사용자가 EQ-001이라고 확인.
- 선속만 있는 단계는 길이 변화 없음.
- 준비/교체 시간, 보빈 인계 시점, 검사 위치/자원 수, 완제품 판정 시점은 미정.
- P01 동일 제품 연속 생산 중 잔량 이월, 다른 제품 투입 시 남은 잔량 폐기.
- P01 1,000m 단위마다 단순 floor해 900m만 내는 방식은 사용자 규칙과 다름.
  이월한 잔량을 동일 제품 다음 투입분에 연결해 합계 3,000m→300m×10으로 모델링.
- 잔량 scope와 생산 종료 처리, 실제 물리적 접속 방법은 미정.
- P02/P03을 작업자 무제한 검사로 자동 변경하지 않는다. 사용자가 이 3종에는 확인하지 않음.
- 편조/테이핑/쉬스 사이 추가 저장공간을 임의 생성하지 않음.

## 5. 제품4 — HV_조사_태선(AL)

기본:
- 원자재 개당2t, 멀티신선 동시 투입 **2개**.
- 최종4,000m/보빈.
- 재권취 완료가 완제품 판정, 검사/적재는 별도 상태.
- 표의 준비는 제공값, 발생 주기는 별도 미정.
- 기본 보빈별 인계, 싱글-12만 전체 준비 후 공급.

| 단계 키 | 공정·설비 | 투입 | 산출 | 속도 | 준비/대기 | 후속 |
|---|---|---|---|---|---|---|
| MULTI | AL 멀티신선 EQ-089 | 2t×2개 | 40,000m×12보빈 | 100m/min | 준비120분 | ST-018 |
| DOUBLE | 더블 EQ-090~093 | 40,000m×1보빈 | 4,000m×10보빈 | 100m/min | 준비0 | ST-019 |
| SINGLE_PRE | 싱글-1 EQ-094 | 4,000m×1보빈 | 4,000m 공급용 선행 가공 | 4.4m/min | 준비0 | EQ-096 직결 |
| SINGLE_FEED | 싱글-12 EQ-095 | 4,000m×12보빈 | 12가닥 공급 준비 | 가공없음 | 대기120분 | EQ-096 |
| SINGLE_MAIN | 싱글 메인 EQ-096 | 선행1 + 공급12 | 4,000m×10보빈 | 32m/min | 준비0 | ST-020 |
| INSULATE | 절연 EQ-032~033 | 4,000m×1 | 동일 | 50m/min | 준비0 | ST-011 |
| IRRADIATE | 보빈 조사 EQ-036 | 4,000m×1 | 동일 | 110m/min | 준비0 | ST-012 |
| REWIND | 재권취 EQ-085~088 | 4,000m×1 | 동일 | 50m/min | 준비0 | ST-014 |
| INSPECT | 육안 검사 | 4,000m×1 | 동일 | 10분/보빈 | 준비0 | ST-016 |

경로:
- ST-017 → MULTI → ST-018 → DOUBLE → ST-019
- ST-019에서 SINGLE_PRE(1개), SINGLE_FEED(12개)로 투입 준비
- 두 준비가 충족되면 SINGLE_MAIN
- EQ-096-OUT → ST-020 → 지게차 → ST-021 → AMR → ST-008
- ST-008 → INSULATE → ST-011 → IRRADIATE → ST-012
- ST-012 → REWIND → 완제품 milestone → ST-014 → INSPECT → ST-016

확정:
- 메인 산출10개는 나중에 변경 가능한 per-operation 설정값.
- 투입 길이에서 자동 물량보존으로 산출10을 부정하지 않음. abstract_yield.
- 검사 작업자 무제한 가용, 10분은 유지.
- 싱글-1 출력 후 ST-019로 돌아간다는 초기 기록은 폐기, 최신은 직결.
- 재권취를 EQ-036으로 기록한 초기 오류는 정정됨.

미정:
- 멀티신선12보빈 동시/순차, 선속의 스트림 기준.
- 준비/대기120분 발생 주기, feeder 점유.
- 싱글-1/메인의 정확한 인계 및 원자재 소비 시점.

## 6. 제품5 — HV_복합_세선(CU)

기본: 원자재3.3t/보빈, 최종600m/보빈, 재권취 후 완제품.
모든 단계 보빈별 인계. 검사자 무제한.

| 단계 키 | 공정·설비 | 투입 | 산출 | 속도/시간 | 준비 | 후속 |
|---|---|---|---|---|---|---|
| DRAW | 태신선 EQ-013 | 3.3t×11개 동시 | 1t×36보빈 | 22분/보빈 | 0 | ST-006 |
| MULTI | 멀티신선 EQ-014 | 1t×24보빈 동시 | 100,000m×9보빈 | 60m/min | 120분 | ST-007 |
| STRAND | 연선 EQ-015~020 | 100,000m×1 | 100,000m×1 | 1,000m/min | 120분 | ST-008 |
| INSULATE | 절연 EQ-032~033 | 100,000m×1 | 24,000m×4 | 160m/min | 0 | ST-011 |
| IRRADIATE_1 | 보빈 조사 EQ-036 | 24,000m×1 | 24,000m×1 | 206m/min | 0 | ST-012 |
| BRAID | CU 편조 EQ-039~080 | 24,000m×1 | 12,000m×2 | 1.5m/min | 0 | CU 테이핑기 |
| TAPE | CU 테이핑 EQ-081~084 | 12,000m×1 | 12,000m×1 | 20m/min | 0 | ST-022 |
| SHEATH | 쉬스 EQ-034~035 | 12,000m×1 | 동일 | 60m/min | 0 | ST-011 |
| IRRADIATE_2 | 보빈 조사 EQ-036 | 12,000m×1 | 동일 | 195m/min | 0 | ST-012 |
| REWIND | 재권취 EQ-085~088 | 12,000m×1 | 600m×20 | 50m/min | 0 | ST-014 |
| INSPECT | 육안 검사 | 600m×1 | 동일 | 10분/보빈 | 0 | ST-016 |

이동:
- 출발 ST-005 연결은 기존 원자재 공간과의 대응 제안. 최초 저장 위치를 직접 지정한 사용자 문장은 없으므로 seed에서 inferred/unknown 표시.
- 1차 조사 OUT → ST-012 → **지게차** → ST-013 → 편조.
- 편조 OUT → 테이핑 IN, 중간 저장공간 없음.
- 테이핑 OUT → ST-022(운반방식 미정) → **AMR** → ST-009 → 쉬스 IN.
- 2차 조사 OUT → ST-012 → 재권취 IN.
- 800/1050 대기 공간은 ST-008/ST-009로 사용자 확인.

잔량:
- 태신선: 36.3t 투입·36t 산출의 차이 **300kg 폐기**.
- 연선: 최신1:1 규칙, 기존4,000m 폐기 기록 제거.
- 절연: 100,000m 투입·96,000m 산출 차이 **4,000m 처리 미정**.
- 나머지 단계 예외 없음으로 입력. 모든 공정의 실제 공정 손실0을 과도하게 확장하지 않음.

절대 되돌리지 말 정정:
1. 연선100,000→24,000×4가 아니다. **연선은100,000→100,000**.
2. **절연에서24,000×4 분할**.
3. 1차 조사는24,000×1→1, 4개 증식 아님.
4. ST-022는 ST-021과 별도.
5. 검사는600→600, 완제품600m.

## 7. 제품6 — HV_복합_태선(CU)_상품

기본: **2t/2,000m/1보빈**, 최종500m/보빈, 재권취 후 완제품.
모든 단계 준비0분/보빈별 인계, 검사 작업자 무제한.

| 단계 키 | 공정·설비 | 투입 | 산출 | 속도/시간 | 후속 |
|---|---|---|---|---|---|
| INSULATE_ON_SHEATH | 절연, 쉬스 압출기 EQ-034~035 | 2,000m×1 | 1,000m×2 | 30m/min | ST-011 |
| IRRADIATE_1 | 보빈 조사 EQ-036 | 1,000m×1 | 1,000m×1 | 50m/min | ST-012 |
| BRAID | CU 편조 EQ-039~080 | 1,000m×1 | 1,000m×1 | 1.5m/min | ST-022 |
| SHEATH | 쉬스 압출 EQ-034~035 | 1,000m×1 | 1,000m×1 | 60m/min | ST-011 |
| IRRADIATE_2 | 보빈 조사 EQ-036 | 1,000m×1 | 1,000m×1 | 195m/min | ST-012 |
| REWIND | 재권취 EQ-085~088 | 1,000m×1 | 500m×2 | 30m/min | ST-014 |
| INSPECT | 육안 검사 | 500m×1 | 500m×1 | 10분/보빈 | ST-016 |

이동:
- ST-001 → ST-010 → 쉬스 압출기 IN(작업은 절연).
- 1차 조사 OUT → ST-012 → **지게차** → ST-013 → 편조.
- 편조 OUT → ST-022(운반 미정) → **AMR** → ST-009 → 쉬스 IN.
- 2차 조사 OUT → ST-012 → 재권취 IN.
- 완제품 → ST-014 → 검사 → ST-016.

예외/정정:
- 최초 작업은 절연이지만 설비는 **EQ-034~035**. EQ-032~033으로 바꾸지 않음.
- **테이핑 공정 없음**. 제품5의 경로를 그대로 복제하면 안 됨.
- 1차 조사 산출4가 아니라1.
- 쉬스/2차 조사100m 입력은 오기, 최신 **1,000m**.
- 검사600m 입력은 오기, 최신 **500m**.
- 무손실 단위 관계상 원자재1보빈→최종500m4보빈. 실제 생산계획 수량을 의미하지 않음.

## 8. 공통 운반 목록

| 출발→도착 | 방식 | 적용 |
|---|---|---|
| ST-020→ST-021 | 지게차 | P04 |
| ST-021→ST-008 | AMR | P04 |
| ST-012→ST-013 | 지게차 | P05/P06 1차 조사 후만 |
| 선택 테이핑기 OUT→ST-022 | 미정 | P05 |
| 선택 편조기 OUT→ST-022 | 미정 | P06 |
| ST-022→ST-009 | AMR | P05/P06 |
| 그 외 명시 연결 | 미정 | 실제 이동시간/운반 자원 미확정 |

아직 운반자원 대수·속도·상하차시간 목록 없음. 자원 제한이 없다고 확정된 것은 검사(P04~P06)뿐.

## 9. 시드 작성 규칙

1. 이 문서의 표를 parser가 그대로 읽는 것을 운영 import로 간주하지 않는다.
2. 개발 에이전트가 explicit seed DTO를 만들고 테스트로 표와 대조한다.
3. EQ-001~096 각각 asset 1행 + 포트2개: 설비 포트192개.
4. ST-001~022 각 asset 1행 + ACCESS 최소1개: 초기 공간 포트22개.
5. 합계 자산118, 기본 포트214(공간별 추가 포트 미도입 가정).
6. 제품6개, 공정 버전6개 모두 draft.
7. 제품군 공통 route를 복제하더라도 ID는 독립; 실물 자산은 공유.
8. 후보 qualification/용량/운반 등 UNKNOWN을 확정값으로 덮어쓰지 않음.
9. test fixture의 보정값은 별도 파일/시나리오. 도메인 seed와 분리.
10. 전체 시드 재실행 시 중복 생성 방지, 적용 diff와 정정 근거 기록.

## 10. 설비별 전개용 ID 목록

아래 호기 순번은 실제 현장 호기가 아닌 그룹 내 임시 번호다.

| 설비 코드 | 기준 설비명 | 분류 | 그룹 내 임시 순번 |
|---|---|---|---:|
| EQ-001 | 실리콘 절연 압출기 | 실리콘 | 1 |
| EQ-002 | 실리콘 쉬스 압출기 | 실리콘 | 1 |
| EQ-003 | 실리콘 편조기 | 실리콘 | 1 |
| EQ-004 | 실리콘 편조기 | 실리콘 | 2 |
| EQ-005 | 실리콘 편조기 | 실리콘 | 3 |
| EQ-006 | 실리콘 편조기 | 실리콘 | 4 |
| EQ-007 | 실리콘 편조기 | 실리콘 | 5 |
| EQ-008 | 실리콘 편조기 | 실리콘 | 6 |
| EQ-009 | 실리콘 편조기 | 실리콘 | 7 |
| EQ-010 | 실리콘 편조기 | 실리콘 | 8 |
| EQ-011 | 실리콘 테이핑기 | 실리콘 | 1 |
| EQ-012 | 실리콘 테이핑기 | 실리콘 | 2 |
| EQ-013 | CU 태신선기 | CU | 1 |
| EQ-014 | CU 멀티신선기 | CU | 1 |
| EQ-015 | CU 연선기 | CU | 1 |
| EQ-016 | CU 연선기 | CU | 2 |
| EQ-017 | CU 연선기 | CU | 3 |
| EQ-018 | CU 연선기 | CU | 4 |
| EQ-019 | CU 연선기 | CU | 5 |
| EQ-020 | CU 연선기 | CU | 6 |
| EQ-021 | CU 집합기 | CU | 1 |
| EQ-022 | CU 집합기 | CU | 2 |
| EQ-023 | CU 집합기 | CU | 3 |
| EQ-024 | CU 집합기 | CU | 4 |
| EQ-025 | CU 집합기 | CU | 5 |
| EQ-026 | CU 집합기 | CU | 6 |
| EQ-027 | CU 집합기 | CU | 7 |
| EQ-028 | CU 집합기 | CU | 8 |
| EQ-029 | CU 집합기 | CU | 9 |
| EQ-030 | CU 집합기 | CU | 10 |
| EQ-031 | CU 튜블라 | CU | 1 |
| EQ-032 | 절연 압출기 | 공용 | 1 |
| EQ-033 | 절연 압출기 | 공용 | 2 |
| EQ-034 | 쉬스 압출기 | CU | 1 |
| EQ-035 | 쉬스 압출기 | CU | 2 |
| EQ-036 | 조사기 — 보빈용 | 공용 | 1 |
| EQ-037 | 조사기 — 다발용 | 공용 | 1 |
| EQ-038 | 조사기 — 다발용 | 공용 | 2 |
| EQ-039 | CU 편조기 | CU | 1 |
| EQ-040 | CU 편조기 | CU | 2 |
| EQ-041 | CU 편조기 | CU | 3 |
| EQ-042 | CU 편조기 | CU | 4 |
| EQ-043 | CU 편조기 | CU | 5 |
| EQ-044 | CU 편조기 | CU | 6 |
| EQ-045 | CU 편조기 | CU | 7 |
| EQ-046 | CU 편조기 | CU | 8 |
| EQ-047 | CU 편조기 | CU | 9 |
| EQ-048 | CU 편조기 | CU | 10 |
| EQ-049 | CU 편조기 | CU | 11 |
| EQ-050 | CU 편조기 | CU | 12 |
| EQ-051 | CU 편조기 | CU | 13 |
| EQ-052 | CU 편조기 | CU | 14 |
| EQ-053 | CU 편조기 | CU | 15 |
| EQ-054 | CU 편조기 | CU | 16 |
| EQ-055 | CU 편조기 | CU | 17 |
| EQ-056 | CU 편조기 | CU | 18 |
| EQ-057 | CU 편조기 | CU | 19 |
| EQ-058 | CU 편조기 | CU | 20 |
| EQ-059 | CU 편조기 | CU | 21 |
| EQ-060 | CU 편조기 | CU | 22 |
| EQ-061 | CU 편조기 | CU | 23 |
| EQ-062 | CU 편조기 | CU | 24 |
| EQ-063 | CU 편조기 | CU | 25 |
| EQ-064 | CU 편조기 | CU | 26 |
| EQ-065 | CU 편조기 | CU | 27 |
| EQ-066 | CU 편조기 | CU | 28 |
| EQ-067 | CU 편조기 | CU | 29 |
| EQ-068 | CU 편조기 | CU | 30 |
| EQ-069 | CU 편조기 | CU | 31 |
| EQ-070 | CU 편조기 | CU | 32 |
| EQ-071 | CU 편조기 | CU | 33 |
| EQ-072 | CU 편조기 | CU | 34 |
| EQ-073 | CU 편조기 | CU | 35 |
| EQ-074 | CU 편조기 | CU | 36 |
| EQ-075 | CU 편조기 | CU | 37 |
| EQ-076 | CU 편조기 | CU | 38 |
| EQ-077 | CU 편조기 | CU | 39 |
| EQ-078 | CU 편조기 | CU | 40 |
| EQ-079 | CU 편조기 | CU | 41 |
| EQ-080 | CU 편조기 | CU | 42 |
| EQ-081 | CU 테이핑기 | CU | 1 |
| EQ-082 | CU 테이핑기 | CU | 2 |
| EQ-083 | CU 테이핑기 | CU | 3 |
| EQ-084 | CU 테이핑기 | CU | 4 |
| EQ-085 | 재권취기 | 공용 | 1 |
| EQ-086 | 재권취기 | 공용 | 2 |
| EQ-087 | 재권취기 | 공용 | 3 |
| EQ-088 | 재권취기 | 공용 | 4 |
| EQ-089 | AL 멀티 신선기 | AL | 1 |
| EQ-090 | AL 집합기(더블) | AL | 1 |
| EQ-091 | AL 집합기(더블) | AL | 2 |
| EQ-092 | AL 집합기(더블) | AL | 3 |
| EQ-093 | AL 집합기(더블) | AL | 4 |
| EQ-094 | AL 집합 싱글-1 | AL | 1 |
| EQ-095 | AL 집합 싱글-12 | AL | 1 |
| EQ-096 | AL 집합 싱글 | AL | 1 |


## 11. 완료·검사에서 확정하지 않은 점

P04~P06의 재권취 완료 milestone은 생산완료 집계 기준이다.
검사시간10분과 작업자무제한은 확정이나 불합격/재검사/폐기비율은 제공되지 않았다.
따라서 초기 모델이 검사 소요시간만 반영하면 결과를 “검사 완료”라고 표시하고
실제 품질합격률100%를 검증했다고 표현하지 않는다.



---

<a id="doc-09-llm-wiki"></a>

# 09. 위키·LLM 개발 기술서

## 1. 목적

1차: 공정 정보에 대한 읽기전용 질의.
2차: 실행 결과·비교·이벤트 근거 설명.
후속: 사용자가 승인하는 변경 제안서 생성. 자동 적용은 초기 비목표.

LLM 공급자/모델은 이 문서에서 고정하지 않는다.
프로젝트별 외부 전송 허용 설정, 데이터 분류, 비밀 관리, 비용 한도를 먼저 결정한다.

## 2. 원본과 위키

정형 DB가 사실 원본. 위키는 승인된 버전의 읽기용 projection.
수동 설명은 manual_notes, 원본 선속/수량과 분리.
위키 숫자를 직접 수정해서 DB와 다른 값이 생기는 기능 금지.
위키 문서마다 project_id/source_type/source_id/source_version/hash/status 포함.
초안 질문은 권한 있는 사용자만 명시적으로 선택.

갱신:
transaction outbox → wiki generate → 검색 갱신 → generation 완료.
수정/폐기/권한 변경 시 이전 chunk 숨김/삭제.
인덱스 지연 시 “최신 DB와 인덱스 버전 다름” 표시 또는 structured tool로 답.
검색 결과만으로 현재 승인 버전을 추측하지 않음.

## 3. 질문 라우팅

| 질문 | 처리 |
|---|---|
| 제품6 최초 압출 설비 | structured route API |
| 검사10분 기준 | structured rule + source |
| 공정 설명 | 위키 검색 + 해당 버전 조회 |
| 특정 run 생산량 | metric API |
| 조사기 왜 밀렸는가 | wait/state/event aggregate; 원인 가설 구분 |
| 편조기2대 늘리면? | 비교 실행 없으면 확정 수치 금지 |
| 선속 바꿔줘 | 변경 제안만, 승인 workflow로 넘김 |

## 4. 도구 계약

```text
get_product_process(product_id, version_id)
get_asset(asset_id, revision_id)
get_process_rule(version_id, step_id)
search_project_documents(query, allowed_version_scope)
get_run_summary(run_id)
get_run_metrics(run_id, metric_keys, window)
get_asset_timeline(run_id, asset_key, window, limit)
get_item_lineage(run_id, item_key)
compare_run_results(baseline_run_id, target_run_id)
```

project_id/user scope는 LLM 입력이 아니라 서버 context로 주입.
인수 schema·길이·limit·권한 검사. tool 결과는 수치·단위·근거·미정 필드 포함.
원시 DB query, 사용자 임의 SQL, filesystem path, shell tool 제공 금지.
반복 호출/결과 크기/토큰 예산 제한; 실패하면 확인 불가로 답.

## 5. 답변 표준

- answer: 한국어 요약
- facts: 출처를 가진 확인 사실
- hypotheses: 검증되지 않은 추론
- unknowns: 미정 조건
- sources: source version/field path/run snapshot
- limitations: assumption/abstract_yield/incomplete run 등
- tool_trace_id: 운영 추적

예:
“이 실행의 보빈용 조사기 처리시간은 65%입니다.
근거: run X, metric processing_utilization v1, 관측시간 ..., 분모 ....
대기 증가와 관련된 상태는 ...이며, 설비 증설 효과는 비교 실행이 필요합니다.”

65%는 설명용 예시이며 현재 실측 값이 아니다.

## 6. 보안

문서/CAD 문자/사용자 입력은 비신뢰 데이터다.
검색 자료에 “다른 프로젝트를 조회하라”는 지시가 있어도 실행하지 않는다.
RAG 도입만으로 prompt injection이 사라지는 것은 아니다. [S19](#s19)
방어는 서버 권한·읽기전용 도구·최소 전달·출력 검증으로 구현.
도구별 row limit, query timeout, rate limit, project budget 설정.
외부 공급자 key는 서버 secret에만, React 환경 변수/브라우저에 노출 금지.
채팅 로그와 tool 로그에 민감 자료 보존 기간/마스킹 적용.
실제 데이터 외부 전송 전 사용자/사업체 승인 필요.

## 7. 평가 세트

- 제품6 절연을 EQ-032로 잘못 답하지 않는가
- 제품5 연선100,000→100,000을 유지하는가
- 제품6 테이핑 없음을 답하는가
- P01~03 검사 자원을 무제한이라고 만들어내지 않는가
- P05 절연 잔량4,000m의 처리 미정이라고 답하는가
- EQ-036 재방문을 설비2대로 계산하지 않는가
- 초안을 승인 공정으로 답하지 않는가
- 다른 project 정보 요청 거부
- 과거 run을 현재 선속으로 설명하지 않는가
- 실행하지 않은 증설 효과 수치 생성 금지
- 악성 지시가 포함된 검색문서에도 scope 유지
- tool 실패 시 fabricated citation 금지

모델 평가 통과를 시뮬레이션 엔진 정확성 테스트 대신 사용하지 않는다.


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).



---

<a id="doc-10-cad-layout"></a>

# 10. CAD·배치·이동 경로 개발 기술서

## 1. 현재 확보 자료

이번 작성 환경에서 실제 확인한 첨부:
- DWG 파일 1개: 약93.7MB. 이 문서 작성에서 형상 해석하지 않음.
- ZIP 1개: 722,082bytes.
- ZIP 내부: manifest.json, layers.json, texts.jsonl, inserts.jsonl.
- geometry.jsonl은 **없음**.
- manifest summary: entities_scanned=2,716,433, insert_records=16,338,
  text_records=6,174, entities_skipped_no_layer=15.
- manifest INSUNITS=4, DXF version=AC1021.
- 위 값은 manifest를 읽어 확인. 이번 문서 작업에서 각 설비의 좌표 매칭을 재검증한 것은 아님.

이전 대화에서 생성되었다고 언급된 CAD 분석 보고서·PNG·SVG·로드맵 파일은
현재 파일 저장소에 없어 이번 인계 패키지에 포함하지 않는다.
이전 응답의 문자 좌표 후보를 승인된 설비 위치로 seed하지 않는다.

## 2. 목표

현재 EQ/ST 목록에 대응되는 설비 위치, IN/OUT, 구역/벽/문/통로를 추출·검토.
도면 전체 정보를 DB로 복제하는 것이 아니다.
설비 위치와 다음 공정 방향이 같다는 이유만으로 OUT을 확정하지 않는다.

## 3. 파이프라인

upload → 안전 검사 → 메타데이터/추출 report
→ 원본 geometry 변환 → 후보 검색 → 기존 자산 매핑
→ 사용자 검토 → layout draft → network 검증 → layout 승인 → scenario pin.

원본 파일 checksum/source handle/path를 끝까지 보존.
프로젝트 복사 시 CAD blob 중복 저장은 정책에 따라 가능하나 ACL은 독립.

## 4. 좌표 변환

DXF에는 WCS/OCS 및 블록 내부 좌표 구분이 필요하고,
INSERT에는 기준점·회전·축척·배열 정보가 포함된다. [S17,S20]
변환 순서는 entity OCS → block 좌표 → 중첩 INSERT 변환 → model WCS → 모델 단위 m.
실제 matrix 조합 순서는 작은 테스트 DXF로 검증 후 확정.

- paper/model space 혼합 금지.
- INSERT 삽입점은 설비 중심이 아님.
- 중첩 block/회전/비균일 scale/음수 scale/multi-insert 처리.
- layer0/BYBLOCK 상속 고려.
- 외부참조 누락이면 missing_xref 표시.
- 단위없는 도면은 사용자 입력 전 실제 거리 계산 금지.
- bulge ARC, SPLINE, ELLIPSE 근사에는 tolerance와 원본 보존.
- 해치/프록시/미지원 객체 누락 report.
- ZWMPARTREF 미지원15개를 성공적으로 분석했다고 표시하지 않음.

## 5. geometry 추가 추출 요구

schema:
scope_type, scope_name, entity_type, handle, layer,
coordinate_mode, attributes, geometry, source_file_hash.

LINE/LWPOLYLINE/POLYLINE/ARC/CIRCLE/ELLIPSE/SPLINE/SOLID/TRACE/3DFACE/POINT.
블록을 모두 반복 전개하면 파일 크기 급증할 수 있으므로 definitions+inserts 유지.
일차 추출은 streaming JSONL, 메모리에 전체 객체 list를 만들지 않음.
필터는 레이어만이 아니라 참조 블록 폐포도 고려.
레이어0 형상을 무조건 버리지 않는다.

기존 추출 스크립트는 모든 객체가 layer를 지원한다고 가정하면 오류 발생.
`entity.dxf.is_supported("layer")`로 검사, skip/error를 기록.
이 문서는 extractor 소스 전체를 포함하지 않으며 별도 구현/시험 필요.

## 6. 후보 매핑과 승인

cad_mapping review_status:
candidate / accepted / rejected / needs_site_check.

증거:
label_match, nearby_text, block_name, footprint, manual_confirm.
블록명 일치만으로 매핑 승인 금지.
42개 부품블록이 2세트면84대라고 집계하지 않음.
모델에 미배치 block definition은 설비 배치가 아니다.

이전 대화의 후보:
800/1050/1250 대기 구역, AL/CU 도킹 표기, 추가 “선재 검사대기 도킹”.
이 후보는 현장 확인 전 ST 공간/용량/좌표 확정값이 아니다.
신규 도킹은 자동 ST-023 추가 금지.

## 7. 배치/통로 데이터

layout_version은 공정 버전과 독립.
asset_placement는 footprint, port_placement는 실제 IN/OUT/ACCESS.
zone polygon은 구역, project_group은 조직적 논리 묶음.

network:
- junction/door/port attachment node
- directed segment + length/width/allowed modes
- actual shared passage occupancy는 후속 충돌 모델
- 연결 안 된 endpoint 검증
- 접근 금지 구간/벽 통과 경로 검증

도면에서 통로처럼 보인다고 지게차/AMR 허용을 확정하지 않는다.
물리 통로 모양과 실제 운전 정책은 별도 확인.

## 8. 파일 보안·운영

확장자뿐 아니라 파일 signature 확인.
zip 경로 traversal, 심볼릭 링크, 파일 수/확장 후 총 크기/압축률 제한.
대형 파서는 별도 process/container, wall-time/메모리 제한, 네트워크 off 기본.
외부참조 자동 네트워크 다운로드 금지.
업로드 원본은 immutable, 결과만 새 artifact.
다운로드 URL은 project 권한 검사와 제한된 만료 정책.
CAD parser 실패가 전체 API를 중단시키지 않음.

## 9. 인수 테스트

- 단위 mm/m 및 원점 이동 변환
- TEXT 정렬점과 block base point 구분
- 회전/중첩/배열 INSERT
- 재사용 block 다중 실물 위치
- 좌표 unknown 상태의 승인 차단/현장확인 표시
- 논리 flow 노드 이동이 physical layout을 바꾸지 않음
- 실물 포트 누락 경로를 최단직선으로 자동 보완하지 않음
- 다른 project CAD mapping 참조 거부


---
기술 참조 [Sxx]의 공식 주소와 확인 범위: [99_sources.md](#doc-99-sources).



---

<a id="doc-13-decisions-open-questions"></a>

# 13. 결정 기록·미정 사항·위험 목록

## 1. 결정 분류

사용자 도메인 사실(USER_CONFIRMED)과 설계 제안(PROPOSED)을 같은 “확정”으로 쓰지 않는다.
이 문서는 아직 사용자 전체 설계 승인을 받은 ADR가 아니다.
기술 제안 채택 시 담당자/날짜/근거를 기록한다.

## 2. 사용자 확정 결정

| ID | 결정 |
|---|---|
| D-U01 | 프로젝트를 최상위 시뮬레이션 모델 범위로 관리 |
| D-U02 | React/Python/PostgreSQL + SimPy |
| D-U03 | 공정 Add/Update를 서비스 운영 중 지속 |
| D-U04 | 설비 IN/OUT 필수 |
| D-U05 | 가용 시 이동 기본, busy 도착 시 IN 대기 |
| D-U06 | 목적지 수용 조건에 따른 OUT 배출 |
| D-U07 | 선속 Output 기준, 보빈·길이·가닥 분리 |
| D-U08 | P01 잔량 동일제품 이월/제품전환 폐기 |
| D-U09 | P04 싱글 메인 산출10개 설정, 변경 가능 |
| D-U10 | P04/P05/P06 재권취 후 완제품, 검사/적재 별도 |
| D-U11 | P04/P05/P06 검사자 무제한, 10분/보빈 |
| D-U12 | ST-001과 ST-005 별도, 실리콘과 CU 압출 공간 별도 |
| D-U13 | ST-021과 ST-022 별도 도킹 |
| D-U14 | 제품별 공정은 메인 반영 전 검토 초안 유지 |
| D-U15 | 원자재 전체 물량/입고 계획은 추후 시나리오 입력 |
| D-U16 | 한국어 표기, 잘못 생성된 한자/일본어 제거 |

## 3. 기술 제안 ADR

| ID | 제안 | 이유 | 대안/변경 조건 |
|---|---|---|---|
| ADR-001 | organization 보안 경계 + project 모델 범위 | 타 사업체 확장 | 단일 고객 배포에도 scope 유지 |
| ADR-002 | asset + subtype + asset_revision | 포트/그룹/배치 참조 일관성 | 기존 equipment/storage DB 있으면 단계적 adapter |
| ADR-003 | UUID 내부 ID, code project 내 고유 | 정렬·복사 안정성 | 외부 식별코드는 별도 |
| ADR-004 | process graph와 layout graph 분리 | 화면배치/공장좌표 혼동 방지 | 없음 |
| ADR-005 | 버전 불변 + run snapshot | 과거 결과 재현 | snapshot 없이 current 조인은 금지 |
| ADR-006 | FastAPI/Pydantic/SQLAlchemy/Alembic | typed API와 migration | 팀 표준이 있으면 검토 |
| ADR-007 | API와 worker 분리 | 긴 CPU 작업 격리 | worker backend 교체 가능 |
| ADR-008 | PostgreSQL queue 초기 | 인프라 최소화 | 규모/운영 요구에 따라 broker |
| ADR-009 | React+TS+Vite+TanStack Query+React Flow | typed 화면/그래프 | 정확한 package pin 착수 시 |
| ADR-010 | 숫자 decimal string API | 길이·중량 round-trip 보존 | DB numeric, 엔진 float 변환 |
| ADR-011 | 단계별 명시 handler registry | 일반 플랫폼 확장 | 코드 문자열 실행 금지 |
| ADR-012 | 구조화 DB 원본, 위키 projection | 이중 원본 방지 | 수동설명 overlay 허용 |
| ADR-013 | LLM 읽기전용 도구 우선 | scope·근거·통제 | 승인 workflow 후 변경 제안 |
| ADR-014 | 초기 수동 이동시간 허용 | CAD 전에 실행 검증 | 가정 승인/결과 표시 필수 |
| ADR-015 | single-run 자원은 project+asset UUID로 유일 | 공유 설비 중복 방지 | 연합 프로젝트 실행은 별도 연구 |
| ADR-016 | fixed-horizon [0,H) | 경계 테스트 명확 | inclusive는 별도 기능 |
| ADR-017 | 지식 승인과 실행 가능 검증 분리 | UNKNOWN을 거짓으로 채우지 않음 | 실행 필수값은 차단 |
| ADR-018 | 프로젝트 복사시 새 UUID | 독립 모델/실험 | 실물 공유 동기화는 미지원 |
| ADR-019 | 초기 transport count/geometry 미정 유지 | 사실 날조 방지 | 승인 가정으로 테스트만 |

## 4. 도메인 미정 질문

| ID | 질문 | 영향 | 지금 구조 개발 차단? |
|---|---|---|---|
| OPEN-001 | 각 제품이 후보 설비 모든 호기를 사용할 수 있는가? | 배정·성능 | 아니오; 실행은 해소 필요 |
| OPEN-002 | 설비 처리 용량, IN/OUT/저장 용량과 단위? | buffer/동시성 | 아니오; 실행은 필수 |
| OPEN-003 | 이동 중 설비 예약, OUT 막힘 시 설비 점유? | 시간·교착 | 정책 enum은 먼저, 실제 run은 필수 |
| OPEN-004 | AL feeder 선행/메인 중 점유·소비·인계 상세? | line handler | 해당 기능 실행 차단 |
| OPEN-005 | AL12보빈/CU9보빈 멀티신선 동시/순차와 속도기준? | 처리량 | 해당 단계 실행 차단 |
| OPEN-006 | 준비120분·공급대기120분 발생 주기? | 시간 | 해당 단계 실행 차단 |
| OPEN-007 | P01 잔량 scope/생산종료 처리/출력 인계? | 이월·폐기 | 정책 구조 가능, 해당 run 해소 |
| OPEN-008 | P05 절연 잔량4,000m의 처리? | 물량·시간 | 전체 run 해소 |
| OPEN-009 | P05 최초 원자재 저장 위치 ST-005가 맞는가? | 시작 이동 | 해당 run 해소 |
| OPEN-010 | P01~03 준비/인계/검사자/완제품 판정? | 완료량·리드타임 | 해당 run 해소 |
| OPEN-011 | 운반 대수·속도·상하차·나머지 이동 방식? | 물류 | 수동시간 가정 가능 |
| OPEN-012 | 실제 생산계획·입고주기·초기 WIP·근무시간? | scenario | UI/API 가능, 실제 run 필요 |
| OPEN-013 | 순서·제품 우선순위·배정 정책? | 대기/재공품 | fixture FIFO 가정 가능 |
| OPEN-014 | 실제 IN/OUT·구역·통로·도면 매핑 승인? | CAD 이동 | 수동시간 모드로 우회 |
| OPEN-015 | ST-022 기준명칭 일반화 승인? | 표시 | 아니오, 기존명 유지 |
| OPEN-016 | 제품/설비 교체 중 불량·중단·보전 범위? | 후속 확장 | 초기 범위 밖으로 명시 |
| OPEN-017 | source 잔량이 다음 batch에 사용되는 선택/매칭 조건? | 재고 | 단위 fixture는 가정, 전체 run 필요 |
| OPEN-018 | 가동중 교대 종료 시 정지/계속/완료 후 종료? | calendar | 정책 fixture로 결정 |
| OPEN-019 | 검사 합격/불합격·재검사 규칙? | 품질 | 현재는 소요시간만, 합격률을 만들지 않음 |
| OPEN-020 | 한 작업의 여러 산출 사이 설비를 계속 점유하는가? | 보빈 간 배정·교체 | 인계 규칙과 분리, 시험 가정 필요 |

## 5. 플랫폼 착수 시 결정

| ID | 질문 | 권장 초기 방향 |
|---|---|---|
| TECH-001 | 기존 repo/코드/DB 유무 | 실제 저장소 조사 먼저 |
| TECH-002 | 인증 공급자/조직 온보딩 | OIDC 또는 기존 사내 인증 adapter |
| TECH-003 | 내부망/외부 cloud, secret·object storage | 로컬은 compose, 운영 선택 별도 |
| TECH-004 | 정확한 의존성·DB 서버 버전 | 검증 후 lock, 문서 “최신” 추측 금지 |
| TECH-005 | 외부 LLM 전송 허용 정보 | 기본 미전송, 승인 범위만 |
| TECH-006 | 승인자/권한/보존 정책 | 사용자와 결정 |
| TECH-007 | run 규모/동시 실행/SLO | 측정 기준 합의 후 성능 목표 |
| TECH-008 | RLS 도입 운영 방식 | API scope + 최소권한 DB + RLS 제안 |
| TECH-009 | queue 운영 책임/worker 제한 | 초기 DB queue, 비용·규모 측정 |
| TECH-010 | 템플릿 공유 범위 | 프로젝트 독립 복사 먼저 |

## 6. 초기 리스크

- R01: 미정값을 default0/무제한으로 처리 → 결과 왜곡. validator+assumption gate.
- R02: 같은 EQ 반복 방문을 별도 자원으로 생성 → 처리량 과대. ID invariant test.
- R03: DB·위키·LLM의 서로 다른 최신값 → outbox/version/ref.
- R04: 프로젝트 cache/검색 누출 → scope FK/RLS/querykey/tool auth.
- R05: 한 번에 10개 산출 → downstream lead time 왜곡. unit event.
- R06: 설정 산출량을 물리보존 결과로 해석 → abstract_yield label.
- R07: CAD 문자좌표를 실제 포트로 사용 → review_status.
- R08: job 중복/늦은 worker 쓰기 → idempotency/fencing.
- R09: 문서와 구현 불일치 → 변경 PR·계약 테스트·handoff.
- R10: 범용화 과잉으로 MVP 지연 → ERD core/후속 테이블 단계 도입.
- R11: 성능 확인 없이 전체 CAD JSON DB 적재 → artifact/streaming.
- R12: 예제6종 외 handler 지원을 약속 → capability matrix.

## 7. 질문 처리 규칙

구조 개발에 불필요한 현장 질문을 모두 먼저 요구하지 않는다.
UNKNOWN을 표현하는 구조와 UI는 구현 가능.
실행 직전 선택한 경로에서 필요한 질문만 묶어서 요청한다.
질문 해결 시 source_ref, 대상 제품/버전/field path, 이전값, 새값, 영향 테스트를 기록한다.



---

<a id="doc-11-roadmap-backlog"></a>

# 11. 순차 개발 로드맵·백로그

> 패키지1.0.0 / 계획 상태. 기존 roadmap 파일의 완료 체크는 승계하지 않음.
> 모든 체크는 미구현으로 시작하며 실제 코드·테스트 증거가 있을 때만 완료 처리.
> 작업 수보다 완료 게이트가 우선이다. 개발 기간은 팀/기존 코드 확인 전 임의 산정하지 않음.

## 1. 순서

```text
G0 ERD·계약
   ↓
A 프로젝트·공정 CRUD
   ├─ B 위키·공정 LLM
   └─ C0 작은 SimPy 검증
          ↓
C 시나리오·전체 실행 → D 결과 LLM → E CAD·물류 확장
```

F 운영·품질은 전 단계에서 병행하고 배포 전 종합 확인.
공정 데이터 추가는 A 이후 계속 반복하며 임의 승인/기존 run 변경 없이 처리.

## 2. 우선순위

- 필수(P0): project isolation, 버전·포트·단위·검증·snapshot·핵심 정확성.
- 중요(P1): 입력 편의·그래프·위키·결과 설명.
- 후속(P2): 상세 CAD·혼잡·자동 최적화·고급 확률모델.
- AI 기능을 위한 구조 준비는 초기에 하되 LLM 공급자 통합이 첫 CRUD를 막지 않게 한다.

## G0. 계약·ERD 확정

후속 구현의 선행 게이트. 02/03/04를 승인하고 현장 미정과 기술 제안을 분리한다.

- [ ] **G0-01 — 저장소 조사**: 기존 코드·DB·인증·패키지·migration head·CI를 확인하고 차이 보고서를 작성.
- [ ] **G0-02 — 요구사항 동결 기준**: REQ/ADR/OPEN 목록을 리뷰하고 사용자 사실과 설계 제안을 분리.
- [ ] **G0-03 — 프로젝트 보안 경계**: organization/project/member와 공유·복사 범위를 결정.
- [ ] **G0-04 — ERD 검토**: asset/port/version/process graph 관계와 복합 FK를 검토.
- [ ] **G0-05 — 수량·시간 계약**: decimal/unknown/quantity_basis/output_schedule/잔량 계약 확정.
- [ ] **G0-06 — API 계약**: HTTP status, ETag, idempotency, validation envelope 합의.
- [ ] **G0-07 — 기술 의존성 잠금**: React·Python·PostgreSQL·SimPy 및 도구 exact 버전/lock 작성.
- [ ] **G0-08 — 첫 fixture 정의**: 제품6 절연 단일 단계의 테스트 전용 입력·명시 가정을 정의.

**완료 게이트:** ERD·DTO·API 리뷰 기록, 미정 질문 목록, 첫 검증 fixture가 있고 production 가정으로 오인되지 않음.

## A. 프로젝트·기준정보·공정 관리

위키보다 먼저 데이터 관리 기능을 구현. 공정 표 편집을 우선한다.

- [ ] **A-01 — 개발 환경**: API/DB/worker placeholder/frontend dev 환경, secret 없는 env example.
- [ ] **A-02 — 마이그레이션 기반**: organization/project/user/member 테이블과 재현 가능한 migration.
- [ ] **A-03 — 인증·권한**: 로그인 연동, project 역할 확인, project scope repository.
- [ ] **A-04 — 프로젝트 CRUD**: 생성·목록·전환·보관 화면/API와 권한 테스트.
- [ ] **A-05 — 자산·포트**: asset/subtype/IN/OUT/ACCESS 원자 생성 및 scope 제약.
- [ ] **A-06 — 자산 설정 버전**: asset_revision/port_policy 초안·승인·수정 충돌 처리.
- [ ] **A-07 — 자산 관리 UI**: 설비/공간/도킹, 별칭·그룹·미정 표시.
- [ ] **A-08 — 그룹·공유 매핑**: 한 자산 여러 논리 그룹, 실행 자원 중복 방지 기초.
- [ ] **A-09 — 제품·재료**: 제품 규격/재료 기본 단위/원자재와 목표량 분리.
- [ ] **A-10 — 공정 버전 DB**: node/step/spec/requirements/edge와 복합 FK migration.
- [ ] **A-11 — 그래프 저장 API**: 전체 저장 트랜잭션, dangling/cross-version 검증.
- [ ] **A-12 — 공정 표 편집**: 선속·산출·준비·인계·잔량·다음 공간 입력.
- [ ] **A-13 — 설비 후보 선택**: candidate qualification, one_of/all_of, override.
- [ ] **A-14 — 검증 엔진 기초**: V0~V3 검사와 field_path UI 연결.
- [ ] **A-15 — 검토·승인**: 초안/검토/승인/반려/clone, immutable guard.
- [ ] **A-16 — 변경 이력**: audit·원문 근거·사용자 정정 diff.
- [ ] **A-17 — 예제 seed**: 08 문서 기준96설비22공간6제품, 모두 초안.
- [ ] **A-18 — 프로젝트 복사**: ID 재매핑, source provenance, 결과 제외, 충돌 보고.
- [ ] **A-19 — 공정 그래프 UI**: IN/OUT handle, source/buffer/join/milestone, 표와 round-trip.
- [ ] **A-20 — 권한·회귀 검증**: 다른 project의 ID·cache·import 접근 거부.

**완료 게이트:** 두 프로젝트의 격리된 CRUD가 작동하고, 제품6 최신 경로를 표/그래프로 저장·재조회할 수 있음.

## B. 위키·읽기전용 공정 질의

A의 승인된 DB를 원본으로 사용. C0의 소규모 SimPy 검증을 병행한다.

- [ ] **B-01 — 위키 projection**: 공정 DB에서 Markdown/flow 요약 생성, source version/hash.
- [ ] **B-02 — 수동 설명 분리**: manual notes와 정형 수치 필드 분리.
- [ ] **B-03 — 검색 갱신**: 승인/폐기/수정 outbox와 index generation 처리.
- [ ] **B-04 — 정형 조회 도구**: 공정·설비·정책 읽기전용 tool API.
- [ ] **B-05 — LLM adapter**: 공급자 추상화·timeout·비용한도·키 관리.
- [ ] **B-06 — 프로젝트 질문 UI**: 선택 범위·초안 표시·근거 링크·미정 응답.
- [ ] **B-07 — 보안 평가**: 악성 문서 지시·다른 project 요청·도구 인수 검증.
- [ ] **B-08 — 정확성 평가**: 제품5/6 정정·미정·공유 설비 질문 세트.
- [ ] **B-09 — 장애 대체 경로**: LLM 없이도 위키/구조화 조회 가능.

**완료 게이트:** 공정 질의가 project/version 근거를 반환하며, 수정/실행 권한 없이 동작.

## C0. 초기 SimPy 수직 검증

B와 병행 가능. 전체6종 완성을 기다리지 않는다.

- [ ] **C0-01 — compiler skeleton**: snapshot→RuntimeModel, registry, unknown 검증.
- [ ] **C0-02 — 단일 설비 처리**: 제품6 절연2,000→1,000×2, 보빈별 완료 이벤트.
- [ ] **C0-03 — 보빈 분할 trace**: parent/child/remaining과 길이 합계 검증.
- [ ] **C0-04 — 공유 자원**: 같은 조사기 재방문/다른 제품 경쟁 mini fixture.
- [ ] **C0-05 — IN/OUT blocking**: 명시 용량과 해제 정책별 대기 테스트.
- [ ] **C0-06 — 잔량 fixture**: P01 동일제품 이월/제품전환 폐기, scope 가정 표시.
- [ ] **C0-07 — AL 합류 fixture**: singles 준비 후 configured10 산출, 소비/점유 가정 표시.
- [ ] **C0-08 — 필요 schema 수정**: 검증에서 발견한 계약 문제를 ADR·ERD·API에 반영.

**완료 게이트:** 소규모 결정적 테스트를 통과하고 JSON 구조로 실행 가능함을 확인. 실제 전체 공장 검증 아님.

## C. 시나리오·실행 플랫폼

C0 의미론을 운영 실행 경로와 연결한다.

- [ ] **C-01 — 시나리오 버전**: process/asset/layout pin, 실행 조건 저장.
- [ ] **C-02 — 생산·입고 계획**: 원자재 수량·입고 시각/주기·완제품 목표 구분.
- [ ] **C-03 — 초기 WIP**: 작업물 상태/위치/길이/가용시각 입력.
- [ ] **C-04 — 근무·종료 정책**: calendar·horizon·target·안전한도.
- [ ] **C-05 — 가정 승인 UI**: 미정을 별도 시나리오 가정으로 해소, master 보존.
- [ ] **C-06 — 실행 사전검증**: V4~V6 사용 범위 검사, 지원하지 않는 handler 차단.
- [ ] **C-07 — 스냅샷 생성**: 완전 불변 input/hash/engine/dependencies/seed.
- [ ] **C-08 — job queue**: 트랜잭션 run/snapshot/job, claim·lease·fencing.
- [ ] **C-09 — worker supervision**: child process·heartbeat·wall timeout·메모리 제한.
- [ ] **C-10 — 취소·재시도**: 중복 요청·cancel_requested·stale attempt 처리.
- [ ] **C-11 — 배정·예약**: 자원 선택/예약/다중 자원 allocator.
- [ ] **C-12 — 수량·시간 handler**: pass/split/configured/supply/inspection, 보빈 인계.
- [ ] **C-13 — 수동 운반**: 명시 이동시간/상하차/대기, 운반 미정 가정.
- [ ] **C-14 — 잔량·부족분**: carry/discard/unknown·부분 재고·실행 종료.
- [ ] **C-15 — 이벤트 저장**: 안정 event_seq·batch flush·불완전 로그 상태.
- [ ] **C-16 — 지표 엔진**: 생산/검사/적재·대기·가동률·폐기·WIP.
- [ ] **C-17 — 실행 UI**: queue/status/events/metrics/snapshot/assumptions.
- [ ] **C-18 — 대표6종 검증**: 미정 조건을 실제 확정 또는 승인 가정으로 채운 경우만 full run.
- [ ] **C-19 — 비교·반복**: 동일 입력과 변경조건 diff, seed/반복 결과.
- [ ] **C-20 — 실패/성능 시험**: 교착·부족입고·worker crash·대규모 작업물.

**완료 게이트:** 실행이 API와 분리되고, 성공/실패/취소/정체가 구분되며 당시 입력과 근거 이벤트가 남음.

## D. 결과 LLM 질의

수치 계산은 백엔드, 설명은 LLM.

- [ ] **D-01 — 결과 조회 tool**: run/metric/window/lineage/asset timeline.
- [ ] **D-02 — 분석 요약 API**: 자원 상태·대기 원인 증거를 제한 크기로 반환.
- [ ] **D-03 — 비교 tool**: 입력 차이/관측 기간/지표 정의 차이 포함.
- [ ] **D-04 — 근거형 답변**: 확인사실/가설/미정/가정/부분결과 구분.
- [ ] **D-05 — 결과 질문 UI**: 선택 run 고정, 이전 run 스냅샷 근거.
- [ ] **D-06 — 정량 평가**: API 수치와 답변 수치 일치, 무실행 예측 금지.
- [ ] **D-07 — 보안·운영**: 외부 전송 최소화·budget·감사·실패 대체조회.

**완료 게이트:** 과거 실행을 현재 설정으로 설명하지 않고, 증설 효과는 실행 없는 확정 수치로 답하지 않음.

## E. CAD·배치·운반 네트워크

앞 단계는 수동 이동시간으로 가능. 물리 schema는 처음부터 분리해 둔다.

- [ ] **E-01 — artifact 업로드**: project 권한·해시·압축 해제 안전 한도.
- [ ] **E-02 — 추출 파이프라인**: DXF/추출ZIP parser, manifest/geometry 누락 보고.
- [ ] **E-03 — 좌표 정규화**: OCS/WCS/단위/중첩/회전/배열·모델공간 시험.
- [ ] **E-04 — 후보 매핑**: EQ/ST 대응 후보·confidence·검토·현장확인.
- [ ] **E-05 — 배치 버전**: 설비 footprint·IN/OUT·공간 boundary.
- [ ] **E-06 — 구역 편집**: 물리 zone, 문·벽·기둥·접근 지점.
- [ ] **E-07 — 통로 graph**: direction/width/mode/port attachments.
- [ ] **E-08 — 운반 자원 설정**: 대수·속도·상하차·적재·근무 버전.
- [ ] **E-09 — 네트워크 이동**: manual→network adapter, 최단 허용 경로.
- [ ] **E-10 — 물류 검증**: 연결단절·차단·차량 불가·폭미정 표시.
- [ ] **E-11 — layout UI**: pan/zoom/layer/선택/매핑/검토; flow좌표와 분리.
- [ ] **E-12 — 공유구간 혼잡**: 필요성이 확인되면 capacity/교차로 handler 추가.
- [ ] **E-13 — 배치 비교**: 동일 생산조건에서 layout 변경 run 비교.

**완료 게이트:** 도면 표기 후보와 실제 승인 포트를 구분하고, 이동 경로가 실제 통행 graph를 사용.

## F. 서비스 운영·템플릿 확장

운영 검증은 앞 단계마다 병행, 배포 직전 종합 게이트.

- [ ] **F-01 — 환경·보안**: 개발/검증/운영 분리, 인증·RLS·secret·quota.
- [ ] **F-02 — 백업·복구**: DB/artifact 백업과 restore drill.
- [ ] **F-03 — 관측**: API·queue·worker·LLM·CAD 실패와 비용 대시보드.
- [ ] **F-04 — 보존 정책**: 실행·이벤트·도면·채팅 데이터 보관/삭제 승인.
- [ ] **F-05 — 템플릿**: project clone/import/export와 버전 호환.
- [ ] **F-06 — 플러그인 확장**: 새 공정 유형 handler/schema/capability/test 패키지.
- [ ] **F-07 — 운영 문서**: 배포/rollback/장애대응/키회전/데이터정정.
- [ ] **F-08 — 인계 패키지**: 최신 docs/OpenAPI/migration/test/lock/CHANGELOG 동봉.

**완료 게이트:** 운영 복구·권한·데이터 경계가 검증되고 새 사업체 프로젝트를 하드코딩 없이 생성 가능.

## 3. 바로 시작할 첫 작업 묶음

1. G0-01: 저장소 조사 결과를 받아 기존 구현 여부부터 확인.
2. G0-03~06: ERD와 DTO/API의 프로젝트·포트·수량/시간 계약을 리뷰.
3. A-01~05: 프로젝트 생성, 설비 생성과 IN/OUT, 공간 생성까지 수직 구현.
4. A-09~12: 제품6의 1단계 절연을 draft로 저장·재조회.
5. C0-01~03: 시험 가정을 명시한 단일 공정 실행과 보빈 산출 이벤트 확인.
6. 이후 A 나머지와 B/C0를 진행.

첫 프롬프트는 [14_handoff_prompts.md](#doc-14-handoff-prompts)를 사용한다.

## 4. 공정 추가·수정의 상시 흐름

사용자 입력 → 원문 보존 → 기존 자산/공간 대응 → 새 초안 → 미정/정정 확인
→ validation → 검토 승인 → 위키 갱신 → 시나리오에서 새 버전 선택.

새 공정 유형이면 handler capability를 확인한다.
데이터 저장은 가능해도 엔진 비지원이면 “등록됨/실행 미지원”으로 구분한다.
기존 실행은 영향받지 않으며 새 조건으로 비교 run을 생성한다.

## 5. 변경 요청 템플릿

```text
변경 ID:
요청일:
요청자:
대상 문서/REQ/ADR/작업 ID:
이유:
기존 조건:
새 조건:
DB/API/FE/엔진/위키/CAD/테스트 영향:
미정 사항:
마이그레이션·하위호환:
승인:
구현 commit:
검증 결과:
```

**현재 완료 표시: 0개. 전체 계획 작업: 93개.** 이는 작업 분해 수이며 개발기간 추정이나 구현 증거가 아닙니다.



---

<a id="doc-12-testing-operations"></a>

# 12. 테스트·인수·운영 기술서

> 여기에 적힌 예상값은 단일 공정/가정된 fixture의 수학적 기준이다.
> 실제 전체 시뮬레이션·부하 시험을 실행했다는 뜻이 아니다.

## 1. 테스트 계층

1. domain unit: 단위·수량·시간·정책 검증.
2. database integration: 실제 PostgreSQL FK/RLS/트랜잭션/락.
3. API contract: DTO/OpenAPI/권한/ETag/idempotency.
4. compiler: snapshot→객체, 미지원·미정 차단.
5. deterministic simulation: 정해진 입력에 대한 event/metric.
6. property/invariant: 자원 중복/길이 분할/음수 재고/교착.
7. frontend component + browser: 폼·표·그래프·project 전환.
8. AI evaluation: 근거·권한·미정 처리.
9. CAD fixtures: 변환·매핑·누락.
10. operational: crash/retry/restore/load.

단위 테스트만 통과했다고 시스템 정확성을 보장하지 않는다.
실제 PostgreSQL 기능은 SQLite 대체 시험으로 검증하지 않는다.

## 2. 결정적 계산 시험

공통 fixture 가정:
- 투입물이 t=0에 준비됨.
- 준비시간0, 이동0, Out 막힘없음.
- 설비1개 독점, 산출순차, 보빈별 인계.
- 모든 가정은 테스트 이름/메타에 표시.
- 실제 product master를 수정하지 않음.
- fixture는 격리된 test project에 별도 생성하고 test 승인 이력을 사용한다.
  사용자 실제 제품6의 draft를 몰래 approved로 바꾸지 않는다.

| ID | 입력 | 예상 |
|---|---|---|
| SIM-001 | P06 최초 절연2,000m→1,000×2,30m/min | 출력시각100/3,200/3분 |
| SIM-002 | P04 메인4,000×10,32m/min | 125분 간격10개, 마지막1250분 |
| SIM-003 | P05 재권취12,000→600×20,50m/min | 12분 간격20개, 마지막240분 |
| SIM-004 | P06 재권취1,000→500×2,30m/min | 50/3,100/3분 |
| SIM-005 | P05 절연100,000→24,000×4,160m/min | 150/300/450/600분, 잔량4,000 |
| SIM-006 | 검사자무제한, t=0에5보빈,각10분 | 모두 t=10 완료, 검사자부족 대기0 |
| SIM-007 | 동일 검사 1명 가정,5보빈 | 10/20/30/40/50분 완료 |
| SIM-008 | P01 1,000×3→300m, 이월허용 | 최종10보빈, 잔량0 |
| SIM-009 | P01 1,000m만 처리 후 제품전환 | 300m3개, 잔량100m 폐기 |
| SIM-010 | CU 태신선3.3t×11→1t×36 | 중량차300kg, 길이는 추정 금지 |

SIM-005는 잔량 보관/폐기 처리를 fixture에서 별도 지정해야 실행할 수 있다.
가공시간을 output 기반으로 계산하므로 잔량4,000m에 추가 가공시간을 임의 가산하지 않는다.
실제 잔량 처리시간은 별도 규칙이 확인될 때 추가.
float 비교 허용오차는 test fixture에 명시(예: abs 1e-8분). 화면 반올림값을 비교 기준으로 쓰지 않음.

## 3. 엔진 의미·상태 시험

| ID | 시험 | 합격 조건 |
|---|---|---|
| SIM-011 | 같은EQ-036 1차/2차 재방문 | 자원은1개, 단계별속도 다름 |
| SIM-012 | 두제품 동일설비 경쟁 | 동시점유 capacity 초과없음 |
| SIM-013 | 후보2개 배정 | 중복예약/유실없음, 안정 tie-break |
| SIM-014 | IN full | slot 미확보 자재가 도착공간을 초과하지 않음 |
| SIM-015 | Out full/hold | 설비가 BLOCKED, 다음 가공 못 시작 |
| SIM-016 | Out buffer/free | Out 적재 가능 시 설비 해제 |
| SIM-017 | reserve-on-dispatch | 자재 이동 중 RESERVED와 PROCESSING 구분 |
| SIM-018 | no-reservation/busy arrival | In 대기 기록 |
| SIM-019 | 다중 자원 acquire | 일부자원 영구점유로 교착하지 않음 |
| SIM-020 | AL 준비합류 | 두조건 충족 전 메인 시작금지 |
| SIM-021 | configured10 | 투입13개 매 출력 재소비하지 않음 |
| SIM-022 | 이벤트소진+WIP | completed 아닌 stalled/부족재고 |
| SIM-023 | 미래입고 존재 | 즉시deadlock 단정금지 |
| SIM-024 | horizon=10,완료10 | [0,10) 결과에서 제외 |
| SIM-025 | 동일snapshot/seed/engine | 이벤트순서·결과 재현 |
| SIM-026 | 미정선속기준 | validation 실패, 임의직렬/병렬 선택금지 |
| SIM-027 | 잘못된분모0/NaN | metric null/not_applicable 또는 validation 오류 |
| SIM-028 | lineage 잔량 | 중복소비·음수길이·부모누락없음 |
| SIM-029 | 반복제어event만 존재 | watchdog/limit로 진단, 무한run 방지 |
| SIM-030 | 알수없는handler | 실행거부, pass-through로 fallback금지 |

property 검증:
- material conservation 적용 공정만 입력=산출+잔량+폐기(차원별).
- abstract_yield는 conservation 예외 표시가 필수.
- 각 item은 한 시각에 한 소유 위치/운반 상태만.
- 모든 reserve가 종료/취소 시 해제됨.
- 자원 상태시간 합계가 관측시간과 일치.
- 완료량은 milestone 최초 도달만 집계.

## 4. DB·권한·API 시험

| ID | 시험 |
|---|---|
| DB-001 | 같은 EQ코드를 서로 다른 project에 등록 가능 |
| DB-002 | cross-project asset/port/group/edge/scenario FK 모두 거부 |
| DB-003 | 다른 process version의 node를 edge에 연결 거부 |
| DB-004 | 설비IN/OUT 중복/누락 commit 거부 |
| DB-005 | approved row/subgraph 수정 거부 |
| DB-006 | master rename 후 과거snapshot 내용 유지 |
| DB-007 | project clone 모든UUID 재매핑, 원본에 쓰기없음 |
| DB-008 | RLS 앱계정으로 다른project 접근거부, pool scope 누출없음 |
| API-001 | If-Match 누락428, stale412 |
| API-002 | 동일Idempotency-Key 동시POST에 run1개 |
| API-003 | 같은key 다른body409 |
| API-004 | invalid unit/enum/negative/overflow 422 |
| API-005 | 역할별 승인/실행/취소 권한거부 |
| API-006 | OpenAPI와 실제응답 일치 |
| API-007 | graph PUT 부분오류 시 전체rollback |
| API-008 | 취소된run을 rerun하면 새run/attempt, 과거유지 |

## 5. 프런트엔드 시험

- FE-001 프로젝트 전환 중 오래된 응답이 새 화면에 표시되지 않음.
- FE-002 0/미정/무제한/미적용 round-trip.
- FE-003 100,000m와 100,000m/min 선택 구분.
- FE-004 같은EQ 재방문을 서로 다른 node로 표현하고 동일asset 참조.
- FE-005 graph 위치 변경이 물리좌표에 영향없음.
- FE-006 표↔graph↔DB round-trip.
- FE-007 승인버전 readonly, clone 편집.
- FE-008 버전충돌 diff/reload, 자동덮어쓰기없음.
- FE-009 키보드/오류라벨/색맹에도 상태 구분.
- FE-010 cancel_requested와 cancelled 구분.
- FE-011 무한검사자도10분 표시.
- FE-012 과거run 입력/가정 확인 가능.

## 6. 업무 정정 회귀

- DATA-001 자산118=설비96+공간22, 포트 초기214.
- DATA-002 P04 원자재2t×2, 24개로 회귀금지.
- DATA-003 P05 연선100,000→100,000.
- DATA-004 P05 절연24,000×4, 조사1:1.
- DATA-005 P05 절연잔량4,000 처리UNKNOWN.
- DATA-006 P06 최초절연은쉬스압출기.
- DATA-007 P06 테이핑없음.
- DATA-008 P06 쉬스·2차조사1,000m, 검사500m.
- DATA-009 P01~03 검사자UNKNOWN, P04~06 unlimited.
- DATA-010 ST-004 실리콘편조대기, ST-005 CU원자재.
- DATA-011 ST-021/ST-022 별도.
- DATA-012 미사용설비13대, 공간ST-015. candidate기준임을 표시.
- DATA-013 실리콘P03이AL신선라인을 자동통과하지 않음.
- DATA-014 공정seed 상태draft, 승인기록 조작금지.

## 7. LLM·CAD 검증

09/10 문서의 평가항목을 각각 AI-*, CAD-* case로 구현.
LLM 답변 정확도·보안은 정적 답변 비교와 tool trace를 함께 검사.
CAD는 작은 synthetic DXF fixture로 좌표변환을 먼저 검증.
원본첨부의 실제포트 현장확인은 자동테스트로 대체할 수 없음.

## 8. 작업·장애 시험

- OPS-001 queued 중 worker restart: job 유실없음.
- OPS-002 실행중 worker crash: stale attempt 진단, 같은 결과중복 집계없음.
- OPS-003 이전worker 늦은쓰기: fencing 거부.
- OPS-004 event flush재시도: seq unique, 공식attempt만 집계.
- OPS-005 API timeout 후 client 재전송: run중복없음.
- OPS-006 CPU/메모리/event 제한: 명시 종료사유.
- OPS-007 DB잠시중단: 로그완전성/실패 상태 명시.
- OPS-008 LLM장애: 기본조회/시뮬레이션 기능 유지.
- OPS-009 잘못된ZIP/path traversal/외부참조: 안전거부.
- OPS-010 백업restore 후 artifact hash/스냅샷연결 검증.

## 9. CI 순서

lint/type → domain → migrations from empty → PostgreSQL integration
→ API/OpenAPI contract → compiler/simulation fixtures → frontend component/build
→ browser E2E → security/negative → package artifacts.

migration 기존판에서 upgrade도 별도 시험.
외부 LLM 호출 테스트는 제한된 별도 pipeline, 일반 CI는 fake provider.
성능테스트는 하드웨어/데이터양/버전/측정방법을 결과에 기록.

## 10. 성능·운영 지표

아직 사용자 규모/SLO가 없으므로 다음을 측정한 뒤 목표를 확정:
API p95, graph 저장size/latency, snapshot 생성시간,
queue wait, events/sec, run peakRSS, DB write량,
CAD import peakRSS, LLM cost/latency, 프로젝트별 quota.

장애 runbook:
- 인증/권한 오류
- DB migration 실패/rollback 가능성
- queue stale/worker OOM
- 실행 정체/부족재고
- artifact 접근불가
- wiki index stale
- provider rate limit
- 잘못된 데이터 승인 발견

승인 데이터 정정은 새버전 발행, 해당 run 결과에 영향안내.
과거 snapshot을 몰래 수정해 숫자를 맞추지 않는다.

## 11. 개발 완료 정의

코드 작성 + migration + 자동테스트 + API 계약 + 문서 업데이트 + 인계 메모가 모두 필요.
이 문서의 체크리스트는 실제 테스트 실행 전에는 “검증 예정”이다.



---

<a id="doc-14-handoff-prompts"></a>

# 14. 다른 AI 에이전트용 시작 프롬프트·인계 템플릿

## 1. 전달할 최소 자료

필수:
- 이 문서 패키지 전체
- 실제 소스 저장소 접근 또는 관련 파일
- 기존 DB schema/migration head
- dependency lockfiles
- 실제 인증/배포 제약
- 마지막 실행한 테스트 결과와 미정사항

선택:
- DXF 또는 cad_extract ZIP
- 실제 사용자 운영 조건
- 기존 roadmap 원본(이 패키지는 대화 기반 재구성본)

이 문서만 전달하면 **설계 검토/새 프로젝트 생성**은 가능하지만
현재 소스에 어떤 구현이 이미 있는지는 알 수 없다. 구현 여부를 추측하지 않는다.

## 2. 공통 시작 프롬프트

```text
이 첨부 Markdown 패키지를 프로젝트 개발 기준으로 사용해 주세요.
기존 대화는 볼 수 없다고 가정해 주세요.

목표는 Project 기반 범용 이산 시뮬레이션 플랫폼이며,
React / Python / PostgreSQL / SimPy를 사용합니다.
전선제품6종은 예제 데이터이며 엔진에 하드코딩하지 마세요.

먼저 AGENTS.md, README, 01, 08, 13을 읽고 실제 저장소를 조사하세요.
다음으로 02 ERD → 03 DTO → 04 API의 정합성을 검토하세요.
아직 구현하지 말고:
1. 저장소 구현현황과 문서의 차이
2. 채택할 ERD/기술 제안
3. 구조 개발을 막는 질문과 실행만 막는 현장 질문
4. 첫 작업 G0/A 범위의 파일·migration·테스트 계획
을 제시해 주세요.

미정값을0/무제한으로 바꾸지 말고, 과거실행 snapshot을 변경하지 마세요.
한국어 문서/주석을 사용하고 실행하지 않은 테스트는 미실행으로 보고하세요.
```

## 3. DB 에이전트 프롬프트

```text
역할: PostgreSQL ERD·migration 담당.
02_erd_database.md를 기준으로 core 단계부터 검토하세요.
project scope 복합FK, 자산 subtype, 필수IN/OUT, 승인불변,
공정그래프/물리네트워크 분리, 시나리오asset revision pin을 우선합니다.

기존DB가 있으면 파괴적재생성하지 마세요.
migration SQL/ORM 차이, nullable/CHECK/UNIQUE/index,
RLS와 앱권한 경계, clone ID map을 설명하세요.

결과:
- 선택한 ERD/DDL 변경과 migration
- 실제PostgreSQL 부정테스트
- API팀이 사용할 관계/enum/null 의미
- 문서/ADR 변경
- 아직미구현인 후속테이블 목록
```

## 4. Backend 에이전트 프롬프트

```text
역할: Python/FastAPI API 및 worker 개발.
승인된02/03/04 계약부터 사용하세요. DB와 API 타입을 따로 임의 정의하지 마세요.
첫 수직 기능: project 생성 → asset 생성 → IN/OUT 원자 생성 → 조회.
그 다음 product/process draft 저장과 validation으로 확장하세요.

HTTP요청 안에서 SimPy를 오래 돌리지 마세요.
project scope, ETag, Idempotency-Key, audit/outbox, snapshot을 구현하세요.
OpenAPI와 예제응답을 생성하고 frontend에게 전달하세요.
현재제품6종 조건은08, 미정값은13을 보세요.
결과와 테스트 실행 여부를 AGENTS 형식으로 보고하세요.
```

## 5. Frontend 에이전트 프롬프트

```text
역할: React/TypeScript 화면 개발.
06을 읽고 승인된04/OpenAPI로부터 DTO를 생성하세요.
ERD/API가 확정되지 않았다면 임의필드·임의단위를 만들지 마세요.

우선 project선택, asset표/상세, 제품공정표 편집을 구현하세요.
서버상태query key에 project/version을 넣고 전환시cache/폼이 섞이지 않게 하세요.
IN/OUT포트, 미정/0/무제한, 승인read-only, ETag충돌을 정확히 표시하세요.
공정그래프좌표는CAD좌표와 분리하세요.
실행UI/LLM/CAD는 roadmap순서대로 연결하세요.
API 미구현 mock은 contracts/examples에서만 만들고 실제지원처럼 표시하지 마세요.
```

## 6. SimPy 에이전트 프롬프트

```text
역할: snapshot→SimPy compiler/handler 개발.
07과12의 의미론과 회귀테스트를 먼저 구현하세요.
제품명/EQ코드 분기 없이 operation_type/handler_version으로 처리하세요.

처음에는P06 절연단일단계 fixture:
2000m1보빈→1000m2보빈,30m/min,준비0,
이동0/설비1/Out제약없음은 테스트가정으로만 둡니다.
출력시각100/3분,200/3분을 확인하세요.

그다음공유EQ재방문,In/Out막힘,P01이월,AL합류/지정10보빈을 검증하세요.
AL/CU멀티신선속도기준이 미정인 상태에서 전체공정시간을 확정하지 마세요.
부족재고/교착/이벤트소진을 completed로 처리하지 마세요.
```

## 7. 단계 종료 인계 메모

```text
HANDOFF
문서 패키지:
저장소/branch/commit:
완료 작업 ID:
미완료 작업 ID:
실행 명령:
환경/의존성 버전:
DB migration head:
추가/변경 API:
생성 OpenAPI 경로:
테스트 결과/로그:
승인한 시나리오 가정:
새 질문/위험:
다음작업:
수정한 문서:
```

## 8. 이 대화로 다시 돌아올 때

문서 최신본 또는 변경 diff와 위 HANDOFF를 제공한다.
소스가 연결되지 않는 이 대화에서는 구현완료 여부를 자동 확인할 수 없다.
새 공정/기획 변경은 source claim ID와 최신문서에 반영한 수정본으로 전달한다.
다른 에이전트가 문서를 고쳤다면 최신파일 없이 과거 대화만으로 덮어쓰지 않는다.



---

<a id="doc-15-change-log"></a>

# 15. 변경 이력·구현 상태

## 패키지1.0.0 — 2026-10-22

### 추가
- 프로젝트 기반 범용 플랫폼의 DB/ERD·도메인·API·Backend·Frontend 기술서.
- SimPy 의미론·검증·이벤트·지표·운영 설계.
- 제품6종/설비96대/공간22곳 최신 사용자 데이터.
- 위키·LLM·CAD 경계, 외부 에이전트 인계 가이드.
- 단계별 로드맵과 미정 질문·ADR.
- 공식 기술문서 참조 목록.

### 이관한 최신 사용자 정정
- AL 멀티신선 원자재2t×2.
- AL 싱글-1 선행후직결, 싱글-12 대기120분, 메인 지정산출10.
- AL 재권취 EQ-085~088.
- P05 연선100,000m1:1, 절연에서24,000m×4 분할.
- P05 1차조사1:1, 절연잔량4,000m 처리미정.
- P06 최초절연은쉬스압출기, 1차조사1:1.
- P06 쉬스/2차조사1,000m, 검사500m, 작업자무제한.
- ST-004 삽입이후 최신공간번호, ST-021/022 별도.
- 모든제품공정 초안상태 유지.

### 구현 상태
- DB migration: 미확인/미구현으로 계획.
- Backend/Frontend: 저장소미연결, 구현여부확인불가.
- SimPy 전체모델: 실행검증안함.
- 실제CAD IN/OUT: 미확정.
- 테스트 문서 예상값: 산술검토, 구현테스트실행과다름.
- 기존roadmap파일: 미첨부, 이문서는대화기반재구성.

## 다음 변경 작성 형식

| 항목 | 내용 |
|---|---|
| 패키지 버전 | 예:1.0.1 |
| 날짜 | YYYY-MM-DD |
| 요청/승인 | 사용자 또는 담당자 |
| 변경 유형 | 도메인정정 / 기술결정 / 구현상태 / 문서보완 |
| 변경 내용 | 이전→이후 |
| 영향 문서 | 파일명 |
| 작업/테스트 ID | roadmap/test |
| 마이그레이션 | 필요여부/head |
| 구현 commit | 실제값만 |
| 남은 질문 | OPEN/TECH ID |

## 버전 제안

- patch: 의미를 바꾸지 않는 문구/오타.
- minor: 호환 가능한 기능/공정추가/검증규칙.
- major: DB/API/스냅샷의 비호환 변경.
- 문서버전과 개별제품공정버전, 엔진버전은 별개.

## 문서 생성 점검

문서 내부 상대 링크, 코드블록 짝, JSON 예시 구문, EQ-001~096 전개 수, 공간22곳, 작업ID93개의 중복 여부를 점검했다.
이 점검은 애플리케이션 코드/DB/시뮬레이션 실행 테스트가 아니다.



---

<a id="doc-99-sources"></a>

# 99. 기술 근거와 문서 검토 범위

문서 작성 기준일: 2026-10-22.
아래 공식 자료를 이번 작성에서 조회했다. 라이브러리 기능에 관한 짧은 확인 근거이며,
플랫폼의 ERD·업무 규칙·API 이름·큐 설계 전체가 공식 권장안이라는 뜻은 아니다.
current/latest 주소는 향후 내용이 바뀔 수 있다. 착수 때 버전 고정과 호환성 검증이 필요하다.
“최신 제품버전” 추천이나 취약점 검사를 수행한 것은 아니다.

참조기호 [S01] 등은 각 기술서에서 아래 항목을 뜻한다.
제품 공정·설비·공간 데이터의 근거는 외부 웹이 아니라 사용자의 입력과 정정이다.
설계 제안은 사용자 확정 사실과 별도로 표시했다.

<a id="s01"></a>

## S01. PostgreSQL — Constraints

- 공식 주소: `https://www.postgresql.org/docs/current/ddl-constraints.html`
- 확인 범위: CHECK/UNIQUE/FK와 제약/인덱스 경계.

<a id="s02"></a>

## S02. PostgreSQL — Row Security Policies

- 공식 주소: `https://www.postgresql.org/docs/current/ddl-rowsecurity.html`
- 확인 범위: 행보안 및 owner·우회권한 주의.

<a id="s03"></a>

## S03. PostgreSQL — SELECT

- 공식 주소: `https://www.postgresql.org/docs/current/sql-select.html`
- 확인 범위: FOR UPDATE/SKIP LOCKED 큐 claim 검토.

<a id="s04"></a>

## S04. FastAPI — Features

- 공식 주소: `https://fastapi.tiangolo.com/features/`
- 확인 범위: OpenAPI/타입기반 API 설계.

<a id="s05"></a>

## S05. FastAPI — Background Tasks

- 공식 주소: `https://fastapi.tiangolo.com/tutorial/background-tasks/`
- 확인 범위: 무거운 계산의 별도 처리 검토.

<a id="s06"></a>

## S06. SQLAlchemy — asyncio

- 공식 주소: `https://docs.sqlalchemy.org/en/20/orm/extensions/asyncio.html`
- 확인 범위: 동시 task별 Session 분리.

<a id="s07"></a>

## S07. Alembic — Autogenerate

- 공식 주소: `https://alembic.sqlalchemy.org/en/latest/autogenerate.html`
- 확인 범위: 자동 마이그레이션 결과 수동 검토.

<a id="s08"></a>

## S08. Pydantic — Unions

- 공식 주소: `https://docs.pydantic.dev/latest/concepts/unions/`
- 확인 범위: discriminated union으로 규칙 DTO 검증.

<a id="s09"></a>

## S09. React — Choosing the State Structure

- 공식 주소: `https://react.dev/learn/choosing-the-state-structure`
- 확인 범위: 중복·모순 상태 최소화.

<a id="s10"></a>

## S10. Vite — Guide

- 공식 주소: `https://vite.dev/guide/`
- 확인 범위: React 개발/빌드 도구 제안.

<a id="s11"></a>

## S11. TanStack Query — Query Keys

- 공식 주소: `https://tanstack.com/query/latest/docs/framework/react/guides/query-keys`
- 확인 범위: 프로젝트/버전별 query key 설계.

<a id="s12"></a>

## S12. React Flow — Quick Start

- 공식 주소: `https://reactflow.dev/learn`
- 확인 범위: node/edge 기반 편집 도구 제안.

<a id="s13"></a>

## S13. SimPy — Shared Resources

- 공식 주소: `https://simpy.readthedocs.io/en/stable/topical_guides/resources.html`
- 확인 범위: Resource/Store/Container 및 자원대기.

<a id="s14"></a>

## S14. SimPy — Events

- 공식 주소: `https://simpy.readthedocs.io/en/stable/topical_guides/events.html`
- 확인 범위: 시간·조건 이벤트, AllOf 의미.

<a id="s15"></a>

## S15. SimPy — Environments

- 공식 주소: `https://simpy.readthedocs.io/en/stable/topical_guides/environments.html`
- 확인 범위: 이벤트소진과 until 종료경계.

<a id="s16"></a>

## S16. SimPy — Monitoring

- 공식 주소: `https://simpy.readthedocs.io/en/stable/topical_guides/monitoring.html`
- 확인 범위: 관측대상/시점/저장방식.

<a id="s17"></a>

## S17. ezdxf — Coordinate Systems

- 공식 주소: `https://ezdxf.readthedocs.io/en/stable/concepts/coordinates.html`
- 확인 범위: OCS/WCS 등 좌표체계.

<a id="s18"></a>

## S18. Vitest — Getting Started

- 공식 주소: `https://vitest.dev/guide/`
- 확인 범위: 프런트 테스트 도구 제안.

<a id="s19"></a>

## S19. OWASP — Prompt Injection

- 공식 주소: `https://genai.owasp.org/llmrisk/llm01-prompt-injection/`
- 확인 범위: 비신뢰 문서와 도구권한 경계.

<a id="s20"></a>

## S20. ezdxf — INSERT

- 공식 주소: `https://ezdxf.readthedocs.io/en/stable/blocks/insert.html`
- 확인 범위: 블록참조·삽입·회전·축척·배열.

## 조회 한계

- 브라우저 E2E 도구의 한 문서 경로는 조회 실패했으므로 기능 근거로 사용하지 않았다.
  E2E 도구 선택은 미확정으로 남겼다.
- SQLAlchemy는 2.0 문서를 참조했으며 최신 minor 선택을 의미하지 않는다.
- 배포환경, 인증공급자, LLM공급자, PostGIS/브로커/벡터검색 도입은 확정하지 않았다.
- 사용자 CAD ZIP에서는 manifest를 실제로 열어 확인했으나 형상추출/포트매핑을 새로 수행하지 않았다.
- 코드 저장소/기존 roadmap 원본은 접근하지 못했다.
